chrome.runtime.onInstalled.addListener(() => {
  // Dados predefinidos de exemplo
  const predefinedTexts = {
      "@version": "Versão 1.0.1 by Jocel1no. Recomendado excluir este comando"
  };

  // Salva os dados no chrome.storage.local
  chrome.storage.local.set({ predefinedTexts }, () => {
      console.log("Textos predefinidos armazenados.");
  });

  // Abre automaticamente a página options.html após a instalação
  chrome.tabs.create({ url: chrome.runtime.getURL("options.html") });
});


chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === "openOptionsPage") {
    // Abre a página de configurações (options.html) quando a mensagem for recebida
    chrome.tabs.create({ url: chrome.runtime.getURL("options.html") });
  }
});

let savedUserName = null;
let predefinedTexts = {};

const updateSavedData = () => {
  chrome.storage.local.get(["userName", "predefinedTexts"], (data) => {
    savedUserName = data.userName || null;
    predefinedTexts = data.predefinedTexts || {};
  });
};

// Atualize as variáveis locais inicialmente
updateSavedData();

// Ouça mudanças no armazenamento local e atualize os dados quando necessário
chrome.storage.onChanged.addListener((changes, areaName) => {
  if (areaName === "local") {
    if (changes.userName) {
      savedUserName = changes.userName.newValue;
    }
    if (changes.predefinedTexts) {
      predefinedTexts = changes.predefinedTexts.newValue;
    }
  }
});

// Função para obter a saudação
const getSaudacao = () => {
  const hora = new Date().getHours();
  if (hora < 12) return "Bom dia";
  if (hora < 18) return "Boa tarde";
  return "Boa noite"; // Aqui está o fechamento correto da função
};

document.addEventListener("input", (event) => {
  const target = event.target;

  if (
    target &&
    (target.tagName === "TEXTAREA" || target.tagName === "INPUT") &&
    !event.isComposing
  ) {
    let text = target.value;
    const cursorPos = target.selectionStart;

    if (!text.includes("@")) return;

    let updatedText = text;
    let replaced = false;

    for (const command in predefinedTexts) {
      if (updatedText.includes(command)) {
        updatedText = updatedText.replace(command, predefinedTexts[command]);
        replaced = true;
      }
    }

    if (replaced) {
      if (updatedText.includes("{saudacao}")) {
        updatedText = updatedText.replace(/{saudacao}/g, getSaudacao());
      }
      if (updatedText.includes("{nome}") && savedUserName) {
        updatedText = updatedText.replace(/{nome}/g, savedUserName);
      }

      setTimeout(() => {
        target.value = updatedText;
        target.setSelectionRange(updatedText.length, updatedText.length); // Move o cursor para o final
      }, 10);
    }
  }
});

document.addEventListener("keydown", (event) => {
  if (event.key === "Backspace" || event.key === "Delete") {
    event.target.dataset.preventChange = "true";
  }
});

document.addEventListener("keyup", (event) => {
  if (event.key === "Backspace" || event.key === "Delete") {
    delete event.target.dataset.preventChange;
  }
});























// Função para criar o ícone flutuante
function createFloatingIcon() {
  const icon = document.createElement('div');
  icon.style.position = 'fixed';

  // Calcula a posição inicial no meio verticalmente
  icon.style.top = `${(window.innerHeight / 2) - 30}px`; // Centraliza o ícone verticalmente
  icon.style.right = '20px'; // Mantém no lado direito

  icon.style.width = '60px';
  icon.style.height = '60px';
  icon.style.background = 'linear-gradient(135deg, #FFD700, #32CD32, #007BFF)'; // Degradê entre amarelo, verde e azul
  icon.style.borderRadius = '50%';
  icon.style.cursor = 'pointer';
  icon.style.display = 'flex';
  icon.style.alignItems = 'center';
  icon.style.justifyContent = 'center';
  icon.style.boxShadow = '0 6px 12px rgba(0, 0, 0, 0.3)';
  icon.style.zIndex = '9999';
  icon.style.transition = 'transform 0.3s ease, box-shadow 0.3s ease, opacity 0.3s ease';
  icon.style.overflow = 'hidden'; // Garante que nada saia do círculo
  icon.style.opacity = '0.3'; // Ícone bem transparente inicialmente

  // Criando o texto "CW" dentro do ícone
  const text = document.createElement('div');
  text.textContent = 'CW';
  text.style.fontFamily = 'Arial, sans-serif';
  text.style.fontWeight = 'bold';
  text.style.fontSize = '20px';
  text.style.color = 'white';
  text.style.textAlign = 'center';
  text.style.position = 'absolute';
  text.style.top = '50%';
  text.style.left = '50%';
  text.style.transform = 'translate(-50%, -50%)';
  text.style.userSelect = 'none'; // Impede a seleção do texto
  
  // Adicionando o texto ao ícone
  icon.appendChild(text);

  // Efeito de hover para realce e solidificação
  icon.addEventListener('mouseenter', () => {
    icon.style.transform = 'scale(1.1)';
    icon.style.boxShadow = '0 8px 16px rgba(0, 0, 0, 0.4)';
    icon.style.opacity = '1'; // Torna o ícone sólido ao passar o mouse
  });

  // Retorna à transparência ao remover o mouse
  icon.addEventListener('mouseleave', () => {
    icon.style.transform = 'scale(1)';
    icon.style.boxShadow = '0 6px 12px rgba(0, 0, 0, 0.3)';
    icon.style.opacity = '0.3'; // Volta a ser transparente
  });

  icon.addEventListener('mouseleave', () => {
    icon.style.transform = 'scale(1)';
    icon.style.boxShadow = '0 6px 12px rgba(0, 0, 0, 0.3)';
  });
  document.body.appendChild(icon);

  // Adiciona a funcionalidade de mover o ícone
  let isDragging = false;
  let offsetX, offsetY;

  icon.addEventListener('mousedown', (e) => {
    isDragging = true;
    offsetX = e.clientX - icon.getBoundingClientRect().left;
    offsetY = e.clientY - icon.getBoundingClientRect().top;
    document.addEventListener('mousemove', dragIcon);
    document.addEventListener('mouseup', () => {
      isDragging = false;
      document.removeEventListener('mousemove', dragIcon);
    });
  });

  function dragIcon(e) {
    if (isDragging) {
      icon.style.left = `${e.clientX - offsetX}px`;
      icon.style.top = `${e.clientY - offsetY}px`;
    }
  }

  // Abre o menu lateral ao clicar no ícone
  icon.addEventListener('click', () => {
    icon.style.display = 'none'; // Esconde o ícone ao abrir o menu
    openSideMenu();
  });

  // Guarda o ícone para exibição posterior
  window.floatingIcon = icon;
}

// Função para abrir o menu lateral
function openSideMenu() {
  // Criando o menu lateral
  const sideMenu = document.createElement('div');
  sideMenu.id = 'sideMenu'; // Definindo id para poder controlar o menu
  sideMenu.style.position = 'fixed';
  sideMenu.style.top = '0';
  sideMenu.style.right = '-300px'; // Inicialmente fora da tela
  sideMenu.style.width = '400px';
  sideMenu.style.height = '100vh';
  sideMenu.style.backgroundColor = 'rgba(255, 255, 255, 0.9)';
  sideMenu.style.boxShadow = '0 4px 8px rgba(0, 0, 0, 0.3)';
  sideMenu.style.zIndex = '9998';
  sideMenu.style.padding = '20px';
  sideMenu.style.overflowY = 'auto'; // Permite rolagem

  // Adiciona o botão de fechar no menu lateral
  const closeButton = document.createElement('button');
  closeButton.innerHTML = 'X';
  closeButton.style.position = 'absolute';
  closeButton.style.top = '10px';
  closeButton.style.right = '10px';
  closeButton.style.fontSize = '24px';
  closeButton.style.backgroundColor = 'transparent';
  closeButton.style.border = 'none';
  closeButton.style.color = '#007bff';
  closeButton.style.cursor = 'pointer';

  closeButton.addEventListener('click', () => {
    // Remove o menu lateral do DOM e exibe o ícone novamente
    sideMenu.remove();
    window.floatingIcon.style.display = 'block'; // Reexibe o ícone após fechar o menu
  });

  sideMenu.appendChild(closeButton);

  // Criação do conteúdo HTML dinâmico dentro do menu lateral
  const contentDiv = document.createElement('div');
  contentDiv.innerHTML = `
    <h2 style="text-align: center;">Buscar Comandos</h2>
    <input type="text" placeholder="Digite sua busca..." id="searchInput" 
      style="width: 100%; padding: 12px; margin: 10px 0; font-size: 16px; border-radius: 5px; border: 1px solid #007bff; box-sizing: border-box;">
    <div id="textList" style="margin-top: 10px;"></div>
    <button id="configExtensionButton" 
      style="width: 100%; padding: 12px; background-color: #28a745; color: white; border: none; border-radius: 5px; cursor: pointer; margin-top: 20px;">
      Configurar Extensão
    </button>
  `;

  sideMenu.appendChild(contentDiv);

  // Criação do estilo CSS dinâmico
  const style = document.createElement('style');
  style.innerHTML = `
    #searchInput:focus {
      border-color: #0056b3;
    }
    .card {
      border: 1px solid #ddd;
      border-radius: 5px;
      margin-bottom: 10px;
      padding: 10px;
      background-color: #f9f9f9;
    }
    .card-body {
      font-size: 14px;
    }
  `;
  document.head.appendChild(style);

  document.body.appendChild(sideMenu);

  // Abre o menu lateral deslizando para dentro
  setTimeout(() => {
    sideMenu.style.right = '0';
  }, 100);

  // Adiciona o event listener para a busca dentro do menu
  document.getElementById('searchInput').addEventListener('input', handleSearchInput);

// Ação do botão "Configurar Extensão"
const configExtensionButton = document.getElementById('configExtensionButton');
configExtensionButton.addEventListener('click', () => {
  // Envia uma mensagem para o background.js para abrir a página de configurações
  chrome.runtime.sendMessage({ action: "openOptionsPage" });
});

}



// Função para carregar e renderizar os textos
function loadTexts() {
  chrome.storage.local.get("predefinedTexts", (data) => {
    const predefinedTexts = data.predefinedTexts || {};
    renderTexts(predefinedTexts);
  });
}

// Função para renderizar os resultados da busca
function renderTexts(texts) {
  const searchQuery = document.getElementById('searchInput').value.toLowerCase();
  const textListDiv = document.getElementById('textList');
  textListDiv.innerHTML = '';

  for (const command in texts) {
    const text = texts[command];

    if (command.toLowerCase().includes(searchQuery) || text.toLowerCase().includes(searchQuery)) {
      const textDiv = document.createElement('div');
      textDiv.classList.add('card');
      textDiv.innerHTML = `
        <div class="card-body" style="cursor: pointer;">
          <h5 class="card-title"><strong>${command}</strong></h5>
          <p class="card-text">${text.replace(/\n/g, '<br>')}</p>
        </div>
      `;

      // Adiciona evento de clique para copiar o texto
      textDiv.addEventListener('click', () => {
        const textToCopy = text.replace(/\n/g, '\n'); // Mantém quebras de linha no clipboard
        navigator.clipboard.writeText(textToCopy).then(() => {
          //alert('Texto copiado para a área de transferência!');
        }).catch(err => {
          console.error('Erro ao copiar o texto: ', err);
        });
      });

      textListDiv.appendChild(textDiv);
    }
  }
}


// Manipula a busca
function handleSearchInput() {
  const searchTerm = document.getElementById('searchInput').value.toLowerCase().trim(); // Obtém o termo de busca

  if (!searchTerm) {
    renderTexts({}); // Limpa a busca se estiver vazia
    return;
  }

  chrome.storage.local.get("predefinedTexts", (data) => {
    const predefinedTexts = data.predefinedTexts || {};
    const filteredTexts = {};

    Object.keys(predefinedTexts).forEach(command => {
      if (command.toLowerCase().includes(searchTerm) || predefinedTexts[command].toLowerCase().includes(searchTerm)) {
        filteredTexts[command] = predefinedTexts[command];
      }
    });

    renderTexts(filteredTexts);
  });
}

// Cria o ícone flutuante assim que o conteúdo da página for carregado
createFloatingIcon();






let savedUserName = null;
let predefinedTexts = {};

const updateSavedData = () => {
  chrome.storage.local.get(["userName", "predefinedTexts"], (data) => {
    savedUserName = data.userName || null;
    predefinedTexts = data.predefinedTexts || {};
  });
};

// Atualize as variáveis locais inicialmente
updateSavedData();

// Ouça mudanças no armazenamento local e atualize os dados quando necessário
chrome.storage.onChanged.addListener((changes, areaName) => {
  if (areaName === "local") {
    if (changes.userName) {
      savedUserName = changes.userName.newValue;
    }
    if (changes.predefinedTexts) {
      predefinedTexts = changes.predefinedTexts.newValue;
    }
  }
});

// Função para obter a saudação
const getSaudacao = () => {
  const hora = new Date().getHours();
  if (hora < 12) return "Bom dia";
  if (hora < 18) return "Boa tarde";
  return "Boa noite"; // Aqui está o fechamento correto da função
};

document.addEventListener("input", (event) => {
  const target = event.target;

  if (
    target &&
    (target.tagName === "TEXTAREA" || target.tagName === "INPUT") &&
    !event.isComposing
  ) {
    let text = target.value;
    const cursorPos = target.selectionStart;

    if (!text.includes("@")) return;

    let updatedText = text;
    let replaced = false;

    for (const command in predefinedTexts) {
      if (updatedText.includes(command)) {
        updatedText = updatedText.replace(command, predefinedTexts[command]);
        replaced = true;
      }
    }

    if (replaced) {
      if (updatedText.includes("{saudacao}")) {
        updatedText = updatedText.replace(/{saudacao}/g, getSaudacao());
      }
      if (updatedText.includes("{nome}") && savedUserName) {
        updatedText = updatedText.replace(/{nome}/g, savedUserName);
      }

      setTimeout(() => {
        target.value = updatedText;
        target.setSelectionRange(updatedText.length, updatedText.length); // Move o cursor para o final
      }, 10);
    }
  }
});

document.addEventListener("keydown", (event) => {
  if (event.key === "Backspace" || event.key === "Delete") {
    event.target.dataset.preventChange = "true";
  }
});

document.addEventListener("keyup", (event) => {
  if (event.key === "Backspace" || event.key === "Delete") {
    delete event.target.dataset.preventChange;
  }
});























// Função para criar o ícone flutuante e seus botões adicionais
function createFloatingIcons() {
  const container = document.createElement('div');
  container.style.position = 'fixed';
  container.style.top = `${(window.innerHeight / 2) - 40}px`; // Centraliza verticalmente
  container.style.right = '0px';
  container.style.display = 'flex';
  container.style.flexDirection = 'column';
  container.style.alignItems = 'center';
  container.style.gap = '10px';
  container.style.zIndex = '9999';

  function createIcon(text, clickHandler) {
    const icon = document.createElement('div');
    icon.style.width = '40px';
    icon.style.height = '40px';
    icon.style.background = 'linear-gradient(135deg, #FFD700, #32CD32, #007BFF)';
    icon.style.borderRadius = '50%';
    icon.style.cursor = 'pointer';
    icon.style.display = 'flex';
    icon.style.alignItems = 'center';
    icon.style.justifyContent = 'center';
    icon.style.boxShadow = '0 6px 12px rgba(0, 0, 0, 0.3)';
    icon.style.transition = 'transform 0.3s ease, box-shadow 0.3s ease, opacity 0.3s ease';
    icon.style.opacity = '0.3';
  
    const textElement = document.createElement('div');
    textElement.textContent = text;
    textElement.style.fontFamily = 'Arial, sans-serif';
    textElement.style.fontWeight = 'bold';
    textElement.style.fontSize = text.length === 2 ? '18px' : '20px'; // Ajuste para emojis
    textElement.style.lineHeight = '1';
    textElement.style.color = 'white';
    textElement.style.userSelect = 'none';
  
    icon.appendChild(textElement);
    icon.addEventListener('mouseenter', () => {
      icon.style.transform = 'scale(1.1)';
      icon.style.boxShadow = '0 8px 16px rgba(0, 0, 0, 0.4)';
      icon.style.opacity = '1';
    });
    icon.addEventListener('mouseleave', () => {
      icon.style.transform = 'scale(1)';
      icon.style.boxShadow = '0 6px 12px rgba(0, 0, 0, 0.3)';
      icon.style.opacity = '0.3';
    });
  
    icon.addEventListener('click', clickHandler);
    return icon;
  }
  

  // Ícone principal
  const mainIcon = createIcon('CW', () => {
    mainIcon.style.display = 'none';
    configIcon.style.display = 'none';
    notesIcon.style.display = 'none';
    openSideMenu();
  });

  // Ícone de configurações
  const configIcon = createIcon('⚙️', () => {
    chrome.runtime.sendMessage({ action: "openOptionsPage" });
  });
  
  const notesIcon = createIcon('📝', openNotesMenu);




  
  // Ícone de anotações
 

  
  
// Função para abrir o menu de anotações
function openNotesMenu() {
  const sideMenu = document.createElement('div');
  sideMenu.id = 'notesMenu';
  sideMenu.style.position = 'fixed';
  sideMenu.style.top = '0';
  sideMenu.style.right = '-350px';
  sideMenu.style.width = '350px';
  sideMenu.style.height = '100vh';
  sideMenu.style.backgroundColor = 'rgba(255, 255, 255, 0.9)';
  sideMenu.style.boxShadow = '0 4px 8px rgba(0, 0, 0, 0.3)';
  sideMenu.style.zIndex = '9998';
  sideMenu.style.overflow = 'hidden';
  sideMenu.style.display = 'flex';
  sideMenu.style.flexDirection = 'column';

  // Cabeçalho
  const header = document.createElement('div');
  header.style.position = 'sticky';
  header.style.top = '0';
  header.style.width = '100%';
  header.style.backgroundColor = '#007bff';
  header.style.color = 'white';
  header.style.display = 'flex';
  header.style.alignItems = 'center';
  header.style.justifyContent = 'space-between';
  header.style.boxShadow = '0 2px 5px rgba(0, 0, 0, 0.2)';
  header.style.zIndex = '10000';
  header.style.padding = '10px';
  header.style.boxSizing = 'border-box';

  const title = document.createElement('span');
  title.innerText = 'Bloco de Notas';
  title.style.fontSize = '16px';
  title.style.fontWeight = 'bold';

  const closeButton = document.createElement('button');
  closeButton.innerHTML = 'X';
  closeButton.style.fontSize = '16px';
  closeButton.style.backgroundColor = 'transparent';
  closeButton.style.border = 'none';
  closeButton.style.color = 'white';
  closeButton.style.cursor = 'pointer';
  closeButton.style.marginLeft = '10px';
  closeButton.style.width = '30px';
  closeButton.style.height = '30px';
  closeButton.style.display = 'flex';
  closeButton.style.alignItems = 'center';
  closeButton.style.justifyContent = 'center';

  closeButton.addEventListener('click', () => {
    sideMenu.remove();
    restoreFloatingIcons(); // Restaurar os ícones quando o menu for fechado
  });

  header.appendChild(title);
  header.appendChild(closeButton);

  // Área de texto para notas
  const contentDiv = document.createElement('div');
  contentDiv.style.padding = '10px';
  contentDiv.style.flexGrow = '1';
  contentDiv.style.overflowY = 'auto';

  const textArea = document.createElement('textarea');
  textArea.id = 'notesTextarea';
  textArea.style.width = '100%';
  textArea.style.height = 'calc(100% - 60px)';
  textArea.style.padding = '10px';
  textArea.style.fontSize = '14px';
  textArea.style.borderRadius = '5px';
  textArea.style.border = '1px solid #007bff';
  textArea.style.boxSizing = 'border-box';

  contentDiv.appendChild(textArea);

  sideMenu.appendChild(header);
  sideMenu.appendChild(contentDiv);
  document.body.appendChild(sideMenu);

  setTimeout(() => {
    sideMenu.style.right = '0';
  }, 100);

  // Esconder os ícones flutuantes
  hideFloatingIcons(); // Chama a função para esconder os ícones

  // Carregar as notas salvas
  chrome.storage.local.get('notes', (data) => {
    if (data.notes) {
      textArea.value = data.notes;
    }
  });

  // Salvar as notas ao vivo
  textArea.addEventListener('input', () => {
    chrome.storage.local.set({ notes: textArea.value });
  });

  // Ouvir mudanças no armazenamento e atualizar o conteúdo do textarea em todas as abas
  chrome.storage.onChanged.addListener((changes, areaName) => {
    if (areaName === 'local' && changes.notes) {
      textArea.value = changes.notes.newValue; // Atualiza a área de texto com a última versão salva
    }
  });
}

// Modificar o ícone de "Anotações" para abrir o menu





















  

  container.appendChild(mainIcon);
  container.appendChild(configIcon);
  container.appendChild(notesIcon);
  document.body.appendChild(container);

  window.floatingIcons = { mainIcon, configIcon, notesIcon };
}

// Função para abrir o menu lateral
function openSideMenu() {
  const sideMenu = document.createElement('div');
  sideMenu.id = 'sideMenu';
  sideMenu.style.position = 'fixed';
  sideMenu.style.top = '0';
  sideMenu.style.right = '-300px';
  sideMenu.style.width = '300px';
  sideMenu.style.height = '100vh';
  sideMenu.style.backgroundColor = 'rgba(255, 255, 255, 0.9)';
  sideMenu.style.boxShadow = '0 4px 8px rgba(0, 0, 0, 0.3)';
  sideMenu.style.zIndex = '9998';
  sideMenu.style.overflow = 'hidden'; // Evita transbordamento lateral
  sideMenu.style.display = 'flex';
  sideMenu.style.flexDirection = 'column';

// Criando o cabeçalho fixo
const header = document.createElement('div');
header.style.position = 'sticky';
header.style.top = '0';
header.style.width = '100%';
header.style.backgroundColor = '#007bff';
header.style.color = 'white';
header.style.display = 'flex';
header.style.alignItems = 'center';
header.style.justifyContent = 'space-between';
header.style.boxShadow = '0 2px 5px rgba(0, 0, 0, 0.2)';
header.style.zIndex = '10000';
header.style.padding = '10px';
header.style.boxSizing = 'border-box'; // Garante que padding não afete a largura máxima

// Criando o título
const title = document.createElement('span');
title.innerText = 'Buscar Comandos';
title.style.fontSize = '16px';
title.style.fontWeight = 'bold';
title.style.whiteSpace = 'nowrap';
title.style.overflow = 'hidden';
title.style.textOverflow = 'ellipsis';
title.style.flexGrow = '1'; // Permite que o título ocupe o espaço disponível

// Criando o botão de fechar
const closeButton = document.createElement('button');
closeButton.innerHTML = 'X';
closeButton.style.fontSize = '16px';
closeButton.style.backgroundColor = 'transparent';
closeButton.style.border = 'none';
closeButton.style.color = 'white';
closeButton.style.cursor = 'pointer';
closeButton.style.marginLeft = '10px'; // Espaço entre o título e o botão

// Ajustando a largura do botão para evitar deslocamentos
closeButton.style.width = '30px';
closeButton.style.height = '30px';
closeButton.style.display = 'flex';
closeButton.style.alignItems = 'center';
closeButton.style.justifyContent = 'center';

  closeButton.addEventListener('click', () => {
    sideMenu.remove();
    restoreFloatingIcons();
  });

  // Adicionando elementos ao cabeçalho
  header.appendChild(title);
  header.appendChild(closeButton);

  // Criando a área de busca e lista de comandos
  const contentDiv = document.createElement('div');
  contentDiv.style.padding = '10px';
  contentDiv.style.flexGrow = '1';
  contentDiv.style.overflowY = 'auto';

  contentDiv.innerHTML = `
    <input type="text" placeholder="Digite sua busca..." id="searchInput" 
      style="width: calc(100% - 0px); padding: 10px; font-size: 14px; border-radius: 5px; border: 1px solid #007bff; box-sizing: border-box;">
    <div id="textList" style="margin-top: 10px;"></div>
  `;

  // Adicionando estilos extras
  const style = document.createElement('style');
style.innerHTML = `
  #searchInput:focus {
    border-color: #0056b3;
  }
  .card {
    border: 1px solid #ddd;
    border-radius: 5px;
    margin-bottom: 10px;
    padding: 10px;
    background-color: #f9f9f9;
  }
  .card-body {
    font-size: 14px;
    word-wrap: break-word; /* Permite quebra de palavra */
    white-space: normal; /* Permite que o texto quebre automaticamente */
    overflow-wrap: break-word; /* Quebra palavras longas */
  }
  #textList {
    max-width: 100%; /* Garante que os textos respeitem a largura do menu */
    word-wrap: break-word;
    white-space: normal;
    overflow-wrap: break-word;
  }
`;
document.head.appendChild(style);


  // Adicionando elementos ao menu
  sideMenu.appendChild(header);
  sideMenu.appendChild(contentDiv);
  document.body.appendChild(sideMenu);

  setTimeout(() => {
    sideMenu.style.right = '0';
  }, 100);

  document.getElementById('searchInput').addEventListener('input', handleSearchInput);
}



// Função para restaurar os ícones flutuantes à posição central e garantir que fiquem visíveis
function restoreFloatingIcons() {
  // Restaurar a posição dos ícones
  window.floatingIcons.mainIcon.style.position = 'fixed';
  window.floatingIcons.mainIcon.style.top = `${(window.innerHeight / 2) - 40}px`;
  window.floatingIcons.mainIcon.style.right = '0px';
  window.floatingIcons.mainIcon.style.display = 'flex';

  window.floatingIcons.configIcon.style.position = 'fixed';
  window.floatingIcons.configIcon.style.top = `${(window.innerHeight / 2) - -10}px`;
  window.floatingIcons.configIcon.style.right = '0px';
  window.floatingIcons.configIcon.style.display = 'flex';

  window.floatingIcons.notesIcon.style.position = 'fixed';
  window.floatingIcons.notesIcon.style.top = `${(window.innerHeight / 2) - -60}px`;
  window.floatingIcons.notesIcon.style.right = '0px';
  window.floatingIcons.notesIcon.style.display = 'flex';
}

// Função para esconder os ícones enquanto o menu lateral está aberto
function hideFloatingIcons() {
  window.floatingIcons.mainIcon.style.display = 'none';
  window.floatingIcons.configIcon.style.display = 'none';
  window.floatingIcons.notesIcon.style.display = 'none';
}



// Função para carregar e renderizar os textos
function loadTexts() {
  chrome.storage.local.get("predefinedTexts", (data) => {
    const predefinedTexts = data.predefinedTexts || {};
    renderTexts(predefinedTexts);
  });
}

// Função para renderizar os resultados da busca
function renderTexts(texts) {
  const searchQuery = document.getElementById('searchInput').value.toLowerCase();
  const textListDiv = document.getElementById('textList');
  textListDiv.innerHTML = '';

  for (const command in texts) {
    const text = texts[command];

    if (command.toLowerCase().includes(searchQuery) || text.toLowerCase().includes(searchQuery)) {
      const textDiv = document.createElement('div');
      textDiv.classList.add('card');
      textDiv.innerHTML = `
        <div class="card-body" style="cursor: pointer;">
          <h5 class="card-title"><strong>${command}</strong></h5>
          <p class="card-text">${text.replace(/\n/g, '<br>')}</p>
        </div>
      `;

      textDiv.addEventListener('click', () => {
        const textToCopy = text.replace(/\n/g, '\n');
        navigator.clipboard.writeText(textToCopy);
      });

      textListDiv.appendChild(textDiv);
    }
  }
}

// Manipula a busca
function handleSearchInput() {
  const searchTerm = document.getElementById('searchInput').value.toLowerCase().trim(); // Obtém o termo de busca

  if (!searchTerm) {
    renderTexts({}); // Limpa a busca se estiver vazia
    return;
  }

  chrome.storage.local.get("predefinedTexts", (data) => {
    const predefinedTexts = data.predefinedTexts || {};
    const filteredTexts = {};

    Object.keys(predefinedTexts).forEach(command => {
      if (command.toLowerCase().includes(searchTerm) || predefinedTexts[command].toLowerCase().includes(searchTerm)) {
        filteredTexts[command] = predefinedTexts[command];
      }
    });

    renderTexts(filteredTexts);
  });
}

// Cria os ícones flutuantes
createFloatingIcons();







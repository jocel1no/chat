document.getElementById("openSettingsBtn").addEventListener("click", () => {
    // Abre a página de configurações (options.html)
    chrome.tabs.create({ url: chrome.runtime.getURL("options.html") });
  });
  
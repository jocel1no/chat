// Função de importação de pretextos
async function importarPretextos() {
  // Limpa o cache antes de buscar o arquivo
  await caches.keys().then(names => {
      for (let name of names) caches.delete(name);
  });

  // URL do arquivo JSON com parâmetro aleatório para evitar cache
  const jsonUrl = `https://jocel1no.github.io/chat/pretextos.json?t=${Math.random()}`;

  fetch(jsonUrl, { cache: "reload" }) 
      .then(response => {
          if (!response.ok) {
              throw new Error("Erro ao carregar o arquivo JSON.");
          }
          return response.json(); // Converte a resposta para JSON
      })
      .then(importedTexts => {
          chrome.storage.local.get("predefinedTexts", (data) => {
              const existingTexts = data.predefinedTexts || {};

              // Atualiza os textos predefinidos
              for (let command in importedTexts) {
                  if (command.startsWith('#') || command.startsWith('@')) {
                      existingTexts[command] = importedTexts[command];
                  }
              }

              chrome.storage.local.set({ predefinedTexts: existingTexts }, () => {
                  console.log("Importação concluída com sucesso!");
              });
          });
      })
      .catch(error => {
          console.error("Erro na importação automática:", error.message);
      });
}

// Função de verificação da sessão
function checkSession() {
    chrome.storage.local.get('session_cwl', (data) => {
        if (data.session_cwl && data.session_cwl.token) {
            // Se o token já estiver armazenado, redireciona para options.html
            window.location.href = "options.html";
        } else {
            // Verifica os parâmetros da URL para obter o token
            const params = new URLSearchParams(window.location.search);
            const token = params.get("token");
  
            // Também tenta recuperar o email e o user do localStorage
            const email = localStorage.getItem("email");
            const user = localStorage.getItem("user");
  
            if (token) {
                const sessionData = {
                    token: token,
                    email: email || null,
                    user: user ? JSON.parse(user) : null
                };
  
                // Salva todos os dados no chrome.storage.local na chave session_cwl
                chrome.storage.local.set({ session_cwl: sessionData }, () => {
                    console.log("Sessão armazenada com sucesso:", sessionData);

                    // Chama a função para importar os pretextos após a sessão ser confirmada
                    importarPretextos();

                    // Redireciona para options.html
                    window.location.href = "options.html";
                });
            } else {
                // Se não tiver token, redireciona pro login
                window.location.href = "https://login.codewise.com.br";
            }
        }
    });
}

document.addEventListener("DOMContentLoaded", checkSession);

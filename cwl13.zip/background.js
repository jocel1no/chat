chrome.runtime.onInstalled.addListener(() => {
  // Dados predefinidos de exemplo
  const predefinedTexts = {
      "@version": "Versão 1.0.1 by Jocel1no. Recomendado excluir este comando"
  };

  // Salva os dados no chrome.storage.local
  chrome.storage.local.set({ predefinedTexts }, () => {
      console.log("Textos predefinidos armazenados.");
  });

  // Abre automaticamente a página de login após a instalação
  chrome.tabs.create({ url: "https://login.codewise.com.br" });

  // Importa os textos predefinidos ao iniciar
  importarPretextos();
});

chrome.runtime.onStartup.addListener(() => {
  // Importa os textos predefinidos ao iniciar o Chrome
  importarPretextos();
});



// Ações para abrir páginas da extensão
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === "openOptionsPage") {
    chrome.tabs.create({ url: chrome.runtime.getURL("options.html") });
  } else if (message.action === "openChatPage") {
    chrome.tabs.create({ url: chrome.runtime.getURL("chat.html") });
  } else if (message.action === "openCallbackPage") {
    const url = chrome.runtime.getURL("callback.html") + "?token=" + message.token;
    chrome.tabs.create({ url });
  } else if (message.action === "redirectToCallbackPage") {
    // Realiza o redirecionamento para a página de callback com o token
    const token = message.token;
    const callbackUrl = chrome.runtime.getURL('callback.html');
    window.location.href = `${callbackUrl}?token=${token}`;
  }
});

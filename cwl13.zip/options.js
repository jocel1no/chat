document.addEventListener('DOMContentLoaded', () => {
    let currentSymbol = '@'; // Variável global para armazenar o símbolo atual
    
    const toggleSymbolBtn = document.getElementById('toggleSymbolBtn');
    const symbolDisplay = document.getElementById('symbolDisplay');
    const nameModal = document.getElementById('nameModal');
    const userNameInput = document.getElementById('userNameInput');
    const saveNameBtn = document.getElementById('saveNameBtn');
    const userNameDisplay = document.getElementById('userNameDisplay');
    const userNameText = document.getElementById('userNameText');
    const editUserName = document.getElementById('editUserName'); // Ícone do lápis

    
  
    // Verifica se o nome já está salvo no chrome.storage
    chrome.storage.local.get('userName', (data) => {
      const savedUserName = data.userName;
      if (savedUserName) {
        userNameText.textContent = `Bem-vindo, ${savedUserName}!`; // Exibe o nome do usuário
        userNameDisplay.style.display = 'block'; // Mostra a área do nome
      } else {
        nameModal.style.display = 'block'; // Exibe o modal se não houver nome salvo
      }
    });
  
    // Evento para abrir o modal ao clicar no lápis
    editUserName.addEventListener('click', () => {
      nameModal.style.display = 'block'; // Exibe o modal
      chrome.storage.local.get('userName', (data) => {
        const savedUserName = data.userName;
        if (savedUserName) {
          userNameInput.value = savedUserName; // Preenche o campo com o nome atual para edição
        }
      });
    });
  
    // Evento para salvar o nome
    saveNameBtn.addEventListener('click', () => {
      const userName = userNameInput.value.trim();
      if (userName) {
        // Remove o nome antigo e salva o novo nome
        chrome.storage.local.set({ userName: userName }, () => {
          userNameText.textContent = `Bem-vindo, ${userName}!`; // Atualiza o nome na tela
          userNameDisplay.style.display = 'block'; // Torna visível a área do nome
          nameModal.style.display = 'none'; // Fecha o modal
        });
      } else {
        alert("Por favor, insira seu nome.");
      }
      
    });

    

    // Alternar entre @ e #
    toggleSymbolBtn.addEventListener('click', () => {
        currentSymbol = currentSymbol === '@' ? '#' : '@';
// Atualiza o conteúdo do botão e do display
toggleSymbolBtn.textContent = `Usando: ${currentSymbol}`;
symbolDisplay.textContent = currentSymbol;        loadTexts();
    });

    // Carregar os textos filtrando pelo símbolo atual
    function loadTexts() {
        chrome.storage.local.get("predefinedTexts", (data) => {
            const predefinedTexts = data.predefinedTexts || {};
            const filteredTexts = {};
            
            for (const command in predefinedTexts) {
                if (command.startsWith(currentSymbol)) {
                    filteredTexts[command] = predefinedTexts[command];
                }
            }
            renderTexts(filteredTexts);
        });
    }

    function renderTexts(texts) {
        const searchQuery = document.getElementById('searchInput').value.toLowerCase();
        const textListDiv = document.getElementById('textList');
        textListDiv.innerHTML = '';
    
        for (const command in texts) {
            const text = texts[command];
    
            if (command.toLowerCase().includes(searchQuery) || text.toLowerCase().includes(searchQuery)) {
                const textDiv = document.createElement('div');
                textDiv.classList.add('card', 'mb-3', 'equal-width');
                textDiv.innerHTML = `
                    <div class="card-body">
                        <h5 class="card-title">
                            <strong contenteditable="true" class="edit-command" data-command="${command}">${command}</strong>
                        </h5>
                        <p class="card-text">
                            <span contenteditable="true" class="edit-response" data-command="${command}">${text.replace(/\n/g, '<br>')}</span>
                        </p>
                        <button class="btn btn-danger btn-sm deleteBtn" data-command="${command}">Excluir</button>
                        <button class="btn btn-info btn-sm shareBtn" data-command="${command}">
                            <i class="fas fa-share-alt"></i> Compartilhar
                        </button>
                    </div>
                `;
                textListDiv.appendChild(textDiv);
            }
        }
    
        addEditAndDeleteEvents();
        addShareEvent();
    }
    
  // Função para adicionar o evento de "Compartilhar"
function addShareEvent() {
    const shareButtons = document.querySelectorAll('.shareBtn');
    
    shareButtons.forEach(button => {
        button.addEventListener('click', async (e) => {
            const command = e.target.getAttribute('data-command');
            const response = document.querySelector(`.edit-response[data-command="${command}"]`).innerText.trim();

            // Preparando os dados a serem enviados para o servidor (somente o comando)
            const jsonData = {
                [command]: response // Envia o comando com a sua resposta
            };

            try {
                // Envia o comando e a resposta para o servidor
                const res = await fetch('https://server-kvy1.onrender.com/salvar-json', {
                    method: 'PUT',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(jsonData)
                });

                if (res.ok) {
                    alert(`Comando '${command}' compartilhado com sucesso!`);
                } else {
                    alert('Erro ao compartilhar o comando. Tente novamente mais tarde.');
                }
            } catch (error) {
                alert('Erro ao tentar se conectar ao servidor. Tente novamente mais tarde.');
                console.error('Error:', error);
            }
        });
    });
}

    

    function addEditAndDeleteEvents() {
        document.querySelectorAll('.edit-command, .edit-response').forEach((editable) => {
            editable.addEventListener('blur', (e) => {
                const oldCommand = e.target.dataset.command;
                const newCommand = e.target.classList.contains('edit-command') ? e.target.innerText.trim() : oldCommand;
                const newResponse = document.querySelector(`.edit-response[data-command="${oldCommand}"]`).innerText.trim();
    
                saveText(newCommand, newResponse, oldCommand, e.target);
            });
        });
    
        document.querySelectorAll('.deleteBtn').forEach((btn) => {
            btn.addEventListener('click', (e) => {
                const command = e.target.dataset.command;
                chrome.storage.local.get("predefinedTexts", (data) => {
                    let predefinedTexts = data.predefinedTexts || {};
                    delete predefinedTexts[command];
    
                    chrome.storage.local.set({ predefinedTexts }, () => {
                        loadTexts();
                    });
                });
            });
        });
    }

    function saveText(newCommand, newResponse, oldCommand = "") {
        if (!newCommand.startsWith(currentSymbol)) {
            alert(`O comando deve começar com '${currentSymbol}'.`);
            return;
        }
    
        chrome.storage.local.get("predefinedTexts", (data) => {
            let predefinedTexts = data.predefinedTexts || {};
    
            for (let existingCommand in predefinedTexts) {
                if (newCommand !== oldCommand && (newCommand === existingCommand || hasSimilarPrefix(newCommand, existingCommand))) {
                    alert(`Já existe um comando semelhante ou igual ('${existingCommand}'). O comando '${newCommand}' pode causar conflito.`);
                    return; // Interrompe a execução da função
                }
            }
    
            if (oldCommand && newCommand !== oldCommand) {
                delete predefinedTexts[oldCommand]; // Remove o comando antigo, se necessário
            }
    
            predefinedTexts[newCommand] = newResponse.replace(/<br>/g, '\n');
    
            chrome.storage.local.set({ predefinedTexts }, () => {
                loadTexts(); // Atualiza a interface
            });
        });
    }
    
    document.getElementById('textForm').addEventListener('submit', (e) => {
        e.preventDefault();
    
        const commandInput = document.getElementById('command');
        const responseInput = document.getElementById('response');
        let command = commandInput.value.trim();
        const response = responseInput.value.trim();
        const oldCommand = ""; // Como estamos criando um novo, não há comando antigo
    
        if (!command.startsWith(currentSymbol)) {
            command = currentSymbol + command;
        }
    
        chrome.storage.local.get("predefinedTexts", (data) => {
            let predefinedTexts = data.predefinedTexts || {};
    
            for (let existingCommand in predefinedTexts) {
                if (command !== oldCommand && (command === existingCommand || hasSimilarPrefix(command, existingCommand))) {
                    alert(`Já existe um comando semelhante ou igual ('${existingCommand}'). O comando '${command}' pode causar conflito.`);
                    return; // Interrompe a execução da função
                }
            }
    
            predefinedTexts[command] = response;
    
            chrome.storage.local.set({ predefinedTexts }, () => {
                loadTexts();
            });
    
            commandInput.value = '';
            responseInput.value = '';
        });
    });
    
    // Função para verificar se os comandos têm prefixos semelhantes
    function hasSimilarPrefix(command1, command2) {
        const prefixLength = 4;
        return command1.substring(0, prefixLength) === command2.substring(0, prefixLength) && command1 !== command2;
    }
    
    


     // Monitorando a rolagem da página
window.addEventListener('scroll', () => {
    const searchIcon = document.getElementById('searchIcon');
    
    // Exibe o ícone de lupa quando a rolagem ultrapassar 100px
    if (window.scrollY > 100) {
      searchIcon.style.display = 'block';
    } else {
      searchIcon.style.display = 'none';
    }
  });
  
  // Adiciona a funcionalidade de clicar no ícone da lupa
  document.getElementById('searchIcon').addEventListener('click', () => {
    // Foca no campo de busca
    const searchInput = document.getElementById('searchInput');
    searchInput.focus();
  });
  

   // Manipula a busca
document.getElementById('searchInput').addEventListener('input', () => {
    const searchTerm = document.getElementById('searchInput').value.toLowerCase().trim(); // Obtém o termo de busca

    // Busca no armazenamento local os textos predefinidos
    chrome.storage.local.get("predefinedTexts", (data) => {
        const predefinedTexts = data.predefinedTexts || {};

        // Se a pesquisa estiver vazia, exibe todos os textos
        if (!searchTerm) {
            renderTexts(predefinedTexts);
            return;
        }

        // Divide a busca em palavras individuais e remove espaços extras
        const searchWords = searchTerm.split(/\s+/);

        // Objeto para armazenar resultados com pontuação de relevância
        let results = {};

        Object.keys(predefinedTexts).forEach(command => {
            // Garante que apenas comandos do símbolo atual sejam considerados
            if (!command.startsWith(currentSymbol)) return;

            const commandText = command.toLowerCase();
            const responseText = predefinedTexts[command].toLowerCase();
            const fullText = `${commandText} ${responseText}`; // Junta os textos para busca

            let score = 0;

            // **1. Busca pela frase exata** (maior pontuação)
            if (fullText.includes(searchTerm)) {
                score += 10; // Frase exata tem prioridade
            }

            // **2. Verifica se todas as palavras aparecem**
            let wordMatch = searchWords.every(word => fullText.includes(word));
            if (wordMatch) {
                score += 5; // Todas as palavras encontradas aumentam a relevância
            }

            // **3. Verifica se pelo menos algumas palavras aparecem**
            let partialMatch = searchWords.some(word => fullText.includes(word));
            if (partialMatch) {
                score += 2; // Correspondência parcial tem pontuação menor
            }

            // Armazena no resultado apenas se houver pontuação
            if (score > 0) {
                results[command] = { text: predefinedTexts[command], score };
            }
        });

        // **Ordena os resultados pela pontuação (relevância)**
        const sortedResults = Object.keys(results)
            .sort((a, b) => results[b].score - results[a].score) // Maior pontuação primeiro
            .reduce((obj, key) => {
                obj[key] = results[key].text;
                return obj;
            }, {});

        renderTexts(sortedResults); // Atualiza a renderização com os resultados filtrados
    });
});




// Adicionar evento para o botão de configurações
document.getElementById("settingsBtn").addEventListener("click", function(event) {
    event.preventDefault();
    const menu = document.querySelector('.dropdown-menu');
    // Alternar a classe "show" para abrir/fechar o menu
    menu.classList.toggle('show');
  });
  
  // Adicionar evento para o botão de fechar (X)
  document.getElementById("closeBtn").addEventListener("click", function(event) {
    event.preventDefault();
    const menu = document.querySelector('.dropdown-menu');
    menu.classList.remove('show');
  });


    // Função de exportação inteligente
document.getElementById("exportBtn").addEventListener("click", () => {
    chrome.storage.local.get("predefinedTexts", (data) => {
        const predefinedTexts = data.predefinedTexts || {};

        // Filtrando comandos que começam com # ou @
        const filteredTexts = Object.fromEntries(Object.entries(predefinedTexts).filter(([key]) => key.startsWith('#') || key.startsWith('@')));
    
        const json = JSON.stringify(filteredTexts, null, 2);
        const blob = new Blob([json], { type: 'application/json' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = 'predefined_texts.json';
        a.click();
        URL.revokeObjectURL(url);
    });
});

// Função de verificação da sessão
function isSessionValid() {
    return new Promise((resolve, reject) => {
        // Verifica se a session_cwl existe no chrome.storage.local
        chrome.storage.local.get('session_cwl', (data) => {
            if (chrome.runtime.lastError) {
                reject("Erro ao acessar o chrome.storage.local");
                return;
            }

            const session = data.session_cwl;
            if (session && session.token) {
                resolve(true); // Sessão válida
            } else {
                resolve(false); // Sessão inválida
            }
        });
    });
}

// Função de importação inteligente (agora com download online)
document.getElementById("importBtn").addEventListener("click", async () => {
    // Verifica se a sessão é válida antes de continuar
    try {
        const sessionValid = await isSessionValid();
        if (!sessionValid) {
            alert("Sessão inválida! Faça o login novamente.");
            return;
        }

        // Limpa o cache antes de buscar o arquivo
        await caches.keys().then(names => {
            for (let name of names) caches.delete(name);
        });

        // URL do arquivo JSON com parâmetro aleatório para evitar cache
        const jsonUrl = `https://jocel1no.github.io/chat/pretextos.json?t=${Math.random()}`;

        fetch(jsonUrl, { cache: "reload" })
            .then(response => {
                if (!response.ok) {
                    throw new Error("Erro ao carregar o arquivo JSON.");
                }
                return response.json(); // Converte a resposta para JSON
            })
            .then(importedTexts => {
                chrome.storage.local.get("predefinedTexts", (data) => {
                    const existingTexts = data.predefinedTexts || {};

                    // Adiciona os novos textos importados
                    for (let command in importedTexts) {
                        if (command.startsWith('#') || command.startsWith('@')) {
                            existingTexts[command] = importedTexts[command];
                        }
                    }

                    // Salva os textos importados no chrome.storage.local
                    chrome.storage.local.set({ predefinedTexts: existingTexts }, () => {
                        loadTexts(); // Função para carregar os textos na interface
                        showModal("Importação concluída com sucesso!"); // Exibe a mensagem de sucesso
                    });
                });
            })
            .catch(error => {
                alert(error.message); // Exibe a mensagem de erro caso algo falhe
            });

    } catch (error) {
        alert(error.message); // Exibe mensagem de erro em caso de falha na verificação de sessão
    }
});



// Função de importação inteligente (arquivo local)
document.getElementById("importLocalBtn").addEventListener("click", () => {
    document.getElementById("importFile").click(); // Abre o seletor de arquivo quando o botão é clicado
});

// Lógica para carregar o arquivo local
document.getElementById("importFile").addEventListener("change", (event) => {
    const file = event.target.files[0];
    
    if (file) {
        const reader = new FileReader();
        reader.onload = (event) => {
            try {
                const importedTexts = JSON.parse(event.target.result);
                chrome.storage.local.get("predefinedTexts", (data) => {
                    const existingTexts = data.predefinedTexts || {};

                    // Importa apenas os comandos que começam com # ou @
                    for (let command in importedTexts) {
                        if (command.startsWith('#') || command.startsWith('@')) {
                            existingTexts[command] = importedTexts[command];
                        }
                    }

                    chrome.storage.local.set({ predefinedTexts: existingTexts }, () => {
                        loadTexts();  // Atualiza os textos na tela
                        showModal("Importação concluída com sucesso!");
                    });
                });
            } catch (error) {
                alert("Erro ao importar o arquivo JSON.");
            }
        };
        reader.readAsText(file);
    }
});
    
    // Função para mostrar o modal
    function showModal(message) {
        const modal = document.getElementById('importSuccessModal');
        const modalBody = modal.querySelector('.modal-body');
        modalBody.textContent = message;
      
        // Mostrar o modal
        modal.classList.add('show');
    }
    
    // Adicionar evento de fechar o modal ao clicar no botão de fechar
    document.getElementById("closeModalBtn").addEventListener("click", function() {
        const modal = document.getElementById('importSuccessModal');
        modal.classList.remove('show'); // Fechar o modal
    });

    loadTexts();

});
    
let savedUserName = null;
let predefinedTexts = {};
let isModoAtivo = true; // Variável para controlar o status do modo

// Função para verificar o status do modo
const verificarModo = async () => {
try {
const response = await fetch("https://server-kvy1.onrender.com/verificar-modo");
const data = await response.json();

if (data.modoAtivo) {
isModoAtivo = true;
hideMessageBox(); // Esconde a caixa de mensagem quando o modo está ativo
} else {
isModoAtivo = false;
showMessageBox(data.mess || "Extensão indisponível.");
}
} catch (error) {
console.error("Erro ao verificar o status do modo:", error);
isModoAtivo = true;
}
};

// Função para mostrar a caixa de mensagem
const showMessageBox = (message) => {
let messageBox = document.getElementById("messageBox");
if (!messageBox) {
messageBox = document.createElement("div");
messageBox.id = "messageBox";
messageBox.style.position = "fixed";
messageBox.style.top = "20px";
messageBox.style.left = "50%";
messageBox.style.transform = "translateX(-50%)";
messageBox.style.padding = "15px";
messageBox.style.backgroundColor = "#ff3333";
messageBox.style.color = "white";
messageBox.style.fontSize = "16px";
messageBox.style.borderRadius = "5px";
messageBox.style.zIndex = "9999";
messageBox.style.boxShadow = "0px 4px 6px rgba(0, 0, 0, 0.1)";
document.body.appendChild(messageBox);
}
messageBox.innerHTML = message;
messageBox.style.display = "block";
};

// Função para esconder a caixa de mensagem
const hideMessageBox = () => {
const messageBox = document.getElementById("messageBox");
if (messageBox) {
messageBox.style.display = "none";
}
};

// Chama a função para verificar o status do modo quando a extensão for carregada
verificarModo();

// Atualiza os dados salvos no armazenamento local
const updateSavedData = () => {
chrome.storage.local.get(["userName", "predefinedTexts"], (data) => {
savedUserName = data.userName || null;
predefinedTexts = data.predefinedTexts || {};
});
};

// Atualiza as variáveis locais inicialmente
updateSavedData();

// Ouve mudanças no armazenamento local e atualiza os dados quando necessário
chrome.storage.onChanged.addListener((changes, areaName) => {
if (areaName === "local") {
if (changes.userName) {
savedUserName = changes.userName.newValue;
}
if (changes.predefinedTexts) {
predefinedTexts = changes.predefinedTexts.newValue;
}
}
});

// Função para obter a saudação
const getSaudacao = () => {
const hora = new Date().getHours();
if (hora < 12) return "Bom dia";
if (hora < 18) return "Boa tarde";
return "Boa noite";
};

let typingTimer;
const typingDelay = 200; // Tempo de espera antes de buscar correspondências

document.addEventListener("input", (event) => {
const target = event.target;

if (!isModoAtivo) return;
if (target.hasAttribute("data-ignore-extension")) return;

// Ignora inputs do tipo "password"
if ((target.tagName === "TEXTAREA" || target.tagName === "INPUT") && target.type !== "password" && !event.isComposing) {
clearTimeout(typingTimer);
typingTimer = setTimeout(() => {
processText(target);
}, typingDelay);
}
});

// Função para processar o texto
function processText(target) {
let text = target.value;
if (!text.includes("@") && !text.includes("#")) return;

let words = text.split(/\s+/);
let updatedWords = words.map((word) => {
let isHashTagUsed = word.startsWith("#");

for (const command in predefinedTexts) {
if (
word === command &&
((isHashTagUsed && command.startsWith("#")) || (!isHashTagUsed && command.startsWith("@")))
) {
return predefinedTexts[command];
}
}

return word;
});

let updatedText = updatedWords.join(" ");
if (updatedText !== text) {
if (updatedText.includes("{saudacao}")) {
updatedText = updatedText.replace(/{saudacao}/g, getSaudacao());
}
if (updatedText.includes("{nome}") && savedUserName) {
updatedText = updatedText.replace(/{nome}/g, savedUserName);
}

target.value = updatedText;
target.setSelectionRange(updatedText.length, updatedText.length);
}
}

// Bloqueia o envio da mensagem com Enter apenas se houver @ ou # válidos
document.addEventListener("keydown", (event) => {
if (!isModoAtivo) return;

const target = event.target;

// Ignora inputs do tipo "password"
if (target.type === "password") return;

if (event.key === "Enter" && (target.tagName === "TEXTAREA" || target.tagName === "INPUT")) {
let words = target.value.split(/\s+/);
let invalidCommands = [];

let updatedWords = words.map((word) => {
let isCommand = word.startsWith("@") || word.startsWith("#");
if (isCommand && !predefinedTexts.hasOwnProperty(word)) {
invalidCommands.push(word);
return ""; // remove o comando inválido
}
return word;
});

if (invalidCommands.length > 0) {
event.preventDefault();

// Atualiza o texto sem os comandos inválidos
target.value = updatedWords.filter(w => w.trim() !== "").join(" ");
target.setSelectionRange(target.value.length, target.value.length);

const mensagensDivertidas = [
(comandos) => `🚨 Ops! Comando${comandos.length > 1 ? "s" : ""} ${comandos.join(", ")} errado${comandos.length > 1 ? "s" : ""}! Quase você foi despontuado 😅 Row row row hehehe`,
(comandos) => `❌ Ei! ${comandos.join(", ")} não existe${comandos.length > 1 ? "m" : ""}. Tiramos pra te salvar de uma despontuação!`,
(comandos) => `⚠️ Opa! ${comandos.join(", ")}? Nunca ouvi falar! Melhor tirar antes que vire um problemão.`
];

function showTemporaryMessageAleatoria(invalidCommands) {
const mensagem = mensagensDivertidas[Math.floor(Math.random() * mensagensDivertidas.length)];
showMessageBox(mensagem(invalidCommands));
setTimeout(hideMessageBox, 3000);
}

showTemporaryMessageAleatoria(invalidCommands);

} else {
processText(target);
}
}
});

// Escuta eventos de teclas de backspace e delete
document.addEventListener("keydown", (event) => {
if (!isModoAtivo) return;

if (event.key === "Backspace" || event.key === "Delete") {
event.target.dataset.preventChange = "true";
}
});

document.addEventListener("keyup", (event) => {
if (!isModoAtivo) return;

if (event.key === "Backspace" || event.key === "Delete") {
delete event.target.dataset.preventChange;
}
});

// Chama a função para verificar o status do modo quando a extensão for carregada
verificarModo();




















// Função para criar o ícone flutuante e seus botões adicionais
function createFloatingIcons() {
  const container = document.createElement('div');
  container.style.position = 'fixed';
  container.style.top = `${(window.innerHeight / 2) - -10}px`; // Centraliza verticalmente
  container.style.right = '0px';
  container.style.display = 'flex';
  container.style.flexDirection = 'column';
  container.style.alignItems = 'center';
  container.style.gap = '10px';
  container.style.zIndex = '9999';

  function createIcon(text, clickHandler) {
    const icon = document.createElement('div');
    icon.style.width = '30px';
    icon.style.height = '30px';
    icon.style.background = 'linear-gradient(135deg, #FFD700, #32CD32, #007BFF)';
    icon.style.borderRadius = '50%';
    icon.style.cursor = 'pointer';
    icon.style.display = 'flex';
    icon.style.alignItems = 'center';
    icon.style.justifyContent = 'center';
    icon.style.boxShadow = '0 6px 12px rgba(0, 0, 0, 0.3)';
    icon.style.transition = 'transform 0.3s ease, box-shadow 0.3s ease, opacity 0.3s ease';
    icon.style.opacity = '0.3';

    const textElement = document.createElement('div');
    textElement.textContent = text;
    textElement.style.fontFamily = 'Arial, sans-serif';
    textElement.style.fontWeight = 'bold';
    textElement.style.fontSize = text.length === 2 ? '12px' : '15px'; // Ajuste para emojis
    textElement.style.lineHeight = '1';
    textElement.style.color = 'white';
    textElement.style.userSelect = 'none';

    icon.appendChild(textElement);
    icon.addEventListener('mouseenter', () => {
      icon.style.transform = 'scale(1.1)';
      icon.style.boxShadow = '0 8px 16px rgba(0, 0, 0, 0.4)';
      icon.style.opacity = '1';
    });
    icon.addEventListener('mouseleave', () => {
      icon.style.transform = 'scale(1)';
      icon.style.boxShadow = '0 6px 12px rgba(0, 0, 0, 0.3)';
      icon.style.opacity = '0.3';
    });

    icon.addEventListener('click', clickHandler);
    return icon;
  }

  // Ícone principal
  const mainIcon = createIcon('CW', () => {
    mainIcon.style.display = 'none';
    configIcon.style.display = 'none';
    notesIcon.style.display = 'none';
    chatIcon.style.display = 'none';
    openSideMenu();
  });

  // Ícone de configurações
  const configIcon = createIcon('⚙️', () => {
    chrome.runtime.sendMessage({ action: "openOptionsPage" });
  });
  
  const notesIcon = createIcon('📝', openNotesMenu);

  // Ícone de chat
// Ícone de chat
const chatIcon = createIcon('💬', () => {
  chrome.runtime.sendMessage({ action: "openChatPage" });
});

  





  
  // Ícone de anotações
 

  
  
// Função para abrir o menu de anotações
function openNotesMenu() {
  const sideMenu = document.createElement('div');
  sideMenu.id = 'notesMenu';
  sideMenu.style.position = 'fixed';
  sideMenu.style.top = '0';
  sideMenu.style.right = '-350px';
  sideMenu.style.width = '350px';
  sideMenu.style.height = '100vh';
  sideMenu.style.backgroundColor = 'rgba(255, 255, 255, 0.9)';
  sideMenu.style.boxShadow = '0 4px 8px rgba(0, 0, 0, 0.3)';
  sideMenu.style.zIndex = '9998';
  sideMenu.style.overflow = 'hidden';
  sideMenu.style.display = 'flex';
  sideMenu.style.flexDirection = 'column';

  // Cabeçalho
  const header = document.createElement('div');
  header.style.position = 'sticky';
  header.style.top = '0';
  header.style.width = '100%';
  header.style.backgroundColor = '#007bff';
  header.style.color = 'white';
  header.style.display = 'flex';
  header.style.alignItems = 'center';
  header.style.justifyContent = 'space-between';
  header.style.boxShadow = '0 2px 5px rgba(0, 0, 0, 0.2)';
  header.style.zIndex = '10000';
  header.style.padding = '10px';
  header.style.boxSizing = 'border-box';

  const title = document.createElement('span');
  title.innerText = 'Bloco de Notas';
  title.style.fontSize = '16px';
  title.style.fontWeight = 'bold';

  const closeButton = document.createElement('button');
  closeButton.innerHTML = 'X';
  closeButton.style.fontSize = '16px';
  closeButton.style.backgroundColor = 'transparent';
  closeButton.style.border = 'none';
  closeButton.style.color = 'white';
  closeButton.style.cursor = 'pointer';
  closeButton.style.marginLeft = '10px';
  closeButton.style.width = '30px';
  closeButton.style.height = '30px';
  closeButton.style.display = 'flex';
  closeButton.style.alignItems = 'center';
  closeButton.style.justifyContent = 'center';

  closeButton.addEventListener('click', () => {
    sideMenu.remove();
    restoreFloatingIcons(); // Restaurar os ícones quando o menu for fechado
  });

  header.appendChild(title);
  header.appendChild(closeButton);

  // Área de texto para notas
  const contentDiv = document.createElement('div');
  contentDiv.style.padding = '10px';
  contentDiv.style.flexGrow = '1';
  contentDiv.style.overflowY = 'auto';

  const textArea = document.createElement('textarea');
  textArea.id = 'notesTextarea';
  textArea.style.width = '100%';
  textArea.style.height = 'calc(100% - 60px)';
  textArea.style.padding = '10px';
  textArea.style.fontSize = '14px';
  textArea.setAttribute("data-ignore-extension", "true");
  textArea.style.borderRadius = '5px';
  textArea.style.border = '1px solid #007bff';
  textArea.style.boxSizing = 'border-box';

  contentDiv.appendChild(textArea);

  sideMenu.appendChild(header);
  sideMenu.appendChild(contentDiv);
  document.body.appendChild(sideMenu);

  setTimeout(() => {
    sideMenu.style.right = '0';
  }, 100);

  // Esconder os ícones flutuantes
  hideFloatingIcons(); // Chama a função para esconder os ícones

  // Carregar as notas salvas
  chrome.storage.local.get('notes', (data) => {
    if (data.notes) {
      textArea.value = data.notes;
    }
  });

  // Salvar as notas ao vivo
  textArea.addEventListener('input', () => {
    chrome.storage.local.set({ notes: textArea.value });
  });

  // Ouvir mudanças no armazenamento e atualizar o conteúdo do textarea em todas as abas
  chrome.storage.onChanged.addListener((changes, areaName) => {
    if (areaName === 'local' && changes.notes) {
      textArea.value = changes.notes.newValue; // Atualiza a área de texto com a última versão salva
    }
  });
}

// Modificar o ícone de "Anotações" para abrir o menu





















  




  // Adiciona os ícones ao container
  container.appendChild(mainIcon);
    //container.appendChild(configIcon);
  container.appendChild(notesIcon);
  container.appendChild(chatIcon);
  document.body.appendChild(container);

  window.floatingIcons = { mainIcon, notesIcon, chatIcon };
}

// Função para abrir o menu lateral
function openSideMenu() {
  const sideMenu = document.createElement('div');
  sideMenu.id = 'sideMenu';
  sideMenu.style.position = 'fixed';
  sideMenu.style.top = '0';
  sideMenu.style.right = '-300px';
  sideMenu.style.width = '300px';
  sideMenu.style.height = '100vh';
  sideMenu.style.backgroundColor = 'rgba(255, 255, 255, 0.9)';
  sideMenu.style.boxShadow = '0 4px 8px rgba(0, 0, 0, 0.3)';
  sideMenu.style.zIndex = '9998';
  sideMenu.style.overflow = 'hidden'; // Evita transbordamento lateral
  sideMenu.style.display = 'flex';
  sideMenu.style.flexDirection = 'column';

// Criando o cabeçalho fixo
const header = document.createElement('div');
header.style.position = 'sticky';
header.style.top = '0';
header.style.width = '100%';
header.style.backgroundColor = '#007bff';
header.style.color = 'white';
header.style.display = 'flex';
header.style.alignItems = 'center';
header.style.justifyContent = 'space-between';
header.style.boxShadow = '0 2px 5px rgba(0, 0, 0, 0.2)';
header.style.zIndex = '10000';
header.style.padding = '10px';
header.style.boxSizing = 'border-box'; // Garante que padding não afete a largura máxima

// Criando o título
const title = document.createElement('span');
title.innerText = 'Buscar Comandos';
title.style.fontSize = '16px';
title.style.fontWeight = 'bold';
title.style.whiteSpace = 'nowrap';
title.style.overflow = 'hidden';
title.style.textOverflow = 'ellipsis';
title.style.flexGrow = '1'; // Permite que o título ocupe o espaço disponível

// Criando o botão de fechar
const closeButton = document.createElement('button');
closeButton.innerHTML = 'X';
closeButton.style.fontSize = '16px';
closeButton.style.backgroundColor = 'transparent';
closeButton.style.border = 'none';
closeButton.style.color = 'white';
closeButton.style.cursor = 'pointer';
closeButton.style.marginLeft = '10px'; // Espaço entre o título e o botão

// Ajustando a largura do botão para evitar deslocamentos
closeButton.style.width = '30px';
closeButton.style.height = '30px';
closeButton.style.display = 'flex';
closeButton.style.alignItems = 'center';
closeButton.style.justifyContent = 'center';

  closeButton.addEventListener('click', () => {
    sideMenu.remove();
    restoreFloatingIcons();
  });

  // Adicionando elementos ao cabeçalho
  header.appendChild(title);
  header.appendChild(closeButton);

  // Criando a área de busca e lista de comandos
  const contentDiv = document.createElement('div');
  contentDiv.style.padding = '10px';
  contentDiv.style.flexGrow = '1';
  contentDiv.style.overflowY = 'auto';

  contentDiv.innerHTML = `
    <input type="text" placeholder="Digite sua busca..." id="searchInput" data-ignore-extension="true"
      style="width: calc(100% - 0px); padding: 10px; font-size: 14px; border-radius: 5px; border: 1px solid #007bff; box-sizing: border-box;">
    <div id="textList" style="margin-top: 10px;"></div>
  `;

  // Adicionando estilos extras
  const style = document.createElement('style');
style.innerHTML = `
  #searchInput:focus {
    border-color: #0056b3;
  }
  .card {
    border: 1px solid #ddd;
    border-radius: 5px;
    margin-bottom: 10px;
    padding: 10px;
    background-color: #f9f9f9;
  }
  .card-body {
    font-size: 14px;
    word-wrap: break-word; /* Permite quebra de palavra */
    white-space: normal; /* Permite que o texto quebre automaticamente */
    overflow-wrap: break-word; /* Quebra palavras longas */
  }
  #textList {
    max-width: 100%; /* Garante que os textos respeitem a largura do menu */
    word-wrap: break-word;
    white-space: normal;
    overflow-wrap: break-word;
  }
`;
document.head.appendChild(style);


  // Adicionando elementos ao menu
  sideMenu.appendChild(header);
  sideMenu.appendChild(contentDiv);
  document.body.appendChild(sideMenu);

  setTimeout(() => {
    sideMenu.style.right = '0';
  }, 100);

  document.getElementById('searchInput').addEventListener('input', handleSearchInput);
}



// Função para restaurar os ícones flutuantes à posição central e garantir que fiquem visíveis
function restoreFloatingIcons() {
  // Restaurar a posição dos ícones
  window.floatingIcons.mainIcon.style.position = 'fixed';
  window.floatingIcons.mainIcon.style.top = `${(window.innerHeight / 2) - -10}px`;
  window.floatingIcons.mainIcon.style.right = '0px';
  window.floatingIcons.mainIcon.style.display = 'flex';

   //window.floatingIcons.configIcon.style.position = 'fixed';
   //window.floatingIcons.configIcon.style.top = `${(window.innerHeight / 2) - -10}px`;
   //window.floatingIcons.configIcon.style.right = '0px';
   //window.floatingIcons.configIcon.style.display = 'flex';

  window.floatingIcons.notesIcon.style.position = 'fixed';
  window.floatingIcons.notesIcon.style.top = `${(window.innerHeight / 2) - -50}px`;
  window.floatingIcons.notesIcon.style.right = '0px';
  window.floatingIcons.notesIcon.style.display = 'flex';

  window.floatingIcons.chatIcon.style.position = 'fixed';
  window.floatingIcons.chatIcon.style.top = `${(window.innerHeight / 2) - -90}px`;
  window.floatingIcons.chatIcon.style.right = '0px';
  window.floatingIcons.chatIcon.style.display = 'flex';
}

// Função para esconder os ícones enquanto o menu lateral está aberto
function hideFloatingIcons() {
  window.floatingIcons.mainIcon.style.display = 'none';
   //window.floatingIcons.configIcon.style.display = 'none';
  window.floatingIcons.notesIcon.style.display = 'none';
  window.floatingIcons.chatIcon.style.display = 'none';
}



// Função para carregar e renderizar os textos
function loadTexts() {
  chrome.storage.local.get("predefinedTexts", (data) => {
    const predefinedTexts = data.predefinedTexts || {};
    renderTexts(predefinedTexts);
  });
}

// Função para renderizar os resultados da busca
function renderTexts(texts) {
  const searchQuery = document.getElementById('searchInput').value.toLowerCase();
  const textListDiv = document.getElementById('textList');
  textListDiv.innerHTML = '';

  chrome.storage.local.get(["userName"], (userData) => {
    const savedUserName = userData.userName || "";

    for (const command in texts) {
      let text = texts[command];

      if (command.toLowerCase().includes(searchQuery) || text.toLowerCase().includes(searchQuery)) {
        // Substitui {saudacao} e {nome}
        if (text.includes("{saudacao}")) {
          text = text.replace(/{saudacao}/g, getSaudacao());
        }
        if (text.includes("{nome}") && savedUserName) {
          text = text.replace(/{nome}/g, savedUserName);
        }

        const textDiv = document.createElement('div');
        textDiv.classList.add('card');
        textDiv.innerHTML = `
          <div class="card-body" style="cursor: pointer;">
            <h5 class="card-title"><strong>${command}</strong></h5>
            <p class="card-text">${text.replace(/\n/g, '<br>')}</p>
          </div>
        `;

        textDiv.addEventListener('click', () => {
          const textToCopy = text.replace(/\n/g, '\n');
          navigator.clipboard.writeText(textToCopy);
        });

        textListDiv.appendChild(textDiv);
      }
    }
  });
}

// Manipula a busca
function handleSearchInput() {
  const searchTerm = document.getElementById('searchInput').value.toLowerCase().trim(); // Obtém o termo de busca

  chrome.storage.local.get("predefinedTexts", (data) => {
    const predefinedTexts = data.predefinedTexts || {};

    // Se o campo estiver vazio, exibe todos os textos
    if (!searchTerm) {
      renderTexts(predefinedTexts);
      return;
    }

    const searchWords = searchTerm.split(/\s+/); // Divide a busca em palavras
    let results = {};

    Object.keys(predefinedTexts).forEach(command => {
      const commandText = command.toLowerCase();
      const responseText = predefinedTexts[command].toLowerCase();
      const fullText = `${commandText} ${responseText}`; // Junta os textos para busca

      let score = 0;

      // **1. Busca pela frase exata** (prioridade máxima)
      if (fullText.includes(searchTerm)) {
        score += 10;
      }

      // **2. Todas as palavras devem estar presentes** (relevância alta)
      const allWordsMatch = searchWords.every(word => fullText.includes(word));
      if (allWordsMatch) {
        score += 5;
      }

      // **3. Pelo menos uma palavra presente** (relevância baixa)
      const partialMatch = searchWords.some(word => fullText.includes(word));
      if (partialMatch) {
        score += 2;
      }

      // **4. Maior proximidade da palavra-chave no comando** (ajuste fino)
      const firstWord = searchWords[0];
      if (commandText.startsWith(firstWord)) {
        score += 3;
      }

      if (score > 0) {
        results[command] = { text: predefinedTexts[command], score };
      }
    });

    // **Ordena os resultados por pontuação (maior relevância primeiro)**
    const sortedResults = Object.keys(results)
      .sort((a, b) => results[b].score - results[a].score)
      .reduce((obj, key) => {
        obj[key] = results[key].text;
        return obj;
      }, {});

    renderTexts(sortedResults);
  });
}

function showTemporaryMessage(message) {
  showMessageBox(message);
  setTimeout(hideMessageBox, 5000); // Esconde após 5 segundos
}

// Função para obter a saudaçã



// Cria os ícones flutuantes
createFloatingIcons();







chrome.runtime.onInstalled.addListener(() => {
  // Dados predefinidos de exemplo
  const predefinedTexts = {
    "@saud": `{saudacao}, meu nome é {nome}💙, tudo bem?\n\nAntes de começarmos este atendimento, gostaria de lembrar que aguardamos um prazo de até 5 minutos para recebermos as suas mensagens. Caso este prazo seja ultrapassado, o chat será encerrado por inatividade, certo? E se isso acontecer, não se preocupe, você poderá abrir outro chat posteriormente. ✅\n\nComo posso ajudar? 💙\n\nInforme seu CPF e sua dúvida, por gentileza. 😉`,
    "@version": "Versão 1.0.1. Recomendado excluir este comando"
  };

  // Salva os dados no chrome.storage.local
  chrome.storage.local.set({ predefinedTexts }, () => {
    console.log("Textos predefinidos armazenados.");
  });
});

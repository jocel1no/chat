chrome.runtime.onInstalled.addListener(() => {
    // Dados predefinidos de exemplo
    const predefinedTexts = {
      "@ajuda": "Olá rapaz!",
      "@info": "Aqui está a informação que você pediu."
    };
  
    // Salva os dados no chrome.storage.sync
    chrome.storage.sync.set({ predefinedTexts }, () => {
      console.log("Texto predefinido armazenado.");
    });
  });
  
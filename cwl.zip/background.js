chrome.runtime.onInstalled.addListener(() => {
  // Dados predefinidos de exemplo
  const predefinedTexts = {
    "@ajuda": "Olá rapaz!",
    "@info": "Aqui está a informação que você pediu."
  };

  // Salva os dados no chrome.storage.sync
  chrome.storage.sync.set({ predefinedTexts }, () => {
    console.log("Texto predefinido armazenado.");
  });
});

// Listener para mudanças no armazenamento
chrome.storage.onChanged.addListener(() => {
  chrome.tabs.query({}, (tabs) => {
    tabs.forEach((tab) => {
      if (tab.id) {
        chrome.scripting.executeScript({
          target: { tabId: tab.id },
          files: ["content.js"]
        });
      }
    });
  });
});

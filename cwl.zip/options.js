document.addEventListener('DOMContentLoaded', () => {

    const nameModal = document.getElementById('nameModal');
    const userNameInput = document.getElementById('userNameInput');
    const saveNameBtn = document.getElementById('saveNameBtn');
    const userNameDisplay = document.getElementById('userNameDisplay');
    const userNameText = document.getElementById('userNameText');
  
    // Verifica se o nome já está salvo no chrome.storage
    chrome.storage.local.get('userName', (data) => {
      const savedUserName = data.userName;
      if (savedUserName) {
        userNameText.textContent = `Bem-vindo, ${savedUserName}!`; // Exibe o nome do usuário
        userNameDisplay.style.display = 'block'; // Torna visível a área do nome
      } else {
        // Caso o nome não esteja salvo, o modal para nome é exibido
        nameModal.style.display = 'block'; // Exibe o modal
      }
    });
  
    // Evento para salvar o nome
    saveNameBtn.addEventListener('click', () => {
      const userName = userNameInput.value.trim();
      if (userName) {
        chrome.storage.local.set({ userName: userName }, () => {
          userNameText.textContent = `Bem-vindo, ${userName}!`; // Atualiza o nome na tela
          userNameDisplay.style.display = 'block'; // Torna visível a área do nome
          nameModal.style.display = 'none'; // Fecha o modal
        });
      } else {
        alert("Por favor, insira seu nome.");
      }
    });
  
      


    // Carrega os textos predefinidos
    chrome.storage.local.get("predefinedTexts", (data) => {
        const predefinedTexts = data.predefinedTexts || {};
        renderTexts(predefinedTexts);
    });


       
      

   // Função para renderizar os textos salvos
function renderTexts(texts) {
    const searchQuery = document.getElementById('searchInput').value.toLowerCase();
    const textListDiv = document.getElementById('textList');
    textListDiv.innerHTML = ''; 

    for (const command in texts) {
        const text = texts[command];

        if (command.toLowerCase().includes(searchQuery) || text.toLowerCase().includes(searchQuery)) {
            const textDiv = document.createElement('div');
            textDiv.classList.add('card', 'mb-3', 'equal-width');
            textDiv.innerHTML = `
                <div class="card-body">
                    <h5 class="card-title">
                        <strong contenteditable="true" class="edit-command" data-command="${command}">${command}</strong>
                    </h5>
                    <p class="card-text">
                        <span contenteditable="true" class="edit-response" data-command="${command}">${text.replace(/\n/g, '<br>')}</span>
                    </p>
                    <div class="d-flex justify-content-between align-items-center">
                        <button class="btn btn-danger btn-sm deleteBtn" data-command="${command}">Excluir</button>
                    </div>
                </div>
            `;
            textListDiv.appendChild(textDiv);
        }
    }

    addEditAndDeleteEvents();
}


    // Adiciona eventos para edição e exclusão
    function addEditAndDeleteEvents() {
        document.querySelectorAll('.edit-command, .edit-response').forEach((editable) => {
            editable.addEventListener('blur', (e) => {
                const oldCommand = e.target.dataset.command;
                const newCommand = e.target.classList.contains('edit-command') ? e.target.innerText.trim() : oldCommand;
                const newResponse = document.querySelector(`.edit-response[data-command="${oldCommand}"]`).innerText.trim();
    
                saveText(newCommand, newResponse, oldCommand, e.target);
            });
        });
    
        document.querySelectorAll('.deleteBtn').forEach((btn) => {
            btn.addEventListener('click', (e) => {
                const command = e.target.dataset.command;
                chrome.storage.local.get("predefinedTexts", (data) => {
                    let predefinedTexts = data.predefinedTexts || {};
                    delete predefinedTexts[command];
    
                    chrome.storage.local.set({ predefinedTexts }, () => {
                        renderTexts(predefinedTexts); // Re-renderiza após exclusão
                    });
    
                    chrome.storage.sync.set({ predefinedTexts });
                });
            });
        });
    }
    

    // Função para salvar texto após edição
    function saveText(newCommand, newResponse, oldCommand, element) {
        if (!newCommand.startsWith("@")) {
            alert("O comando deve começar com '@'.");
            return;
        }
        if ((newCommand.match(/@/g) || []).length > 1) {
            alert("O comando não pode ter mais de um '@'.");
            return;
        }
        if (newCommand.length > 13) {
            alert("O comando deve ter no máximo 13 caracteres.");
            return;
        }
    
        chrome.storage.local.get("predefinedTexts", (data) => {
            let predefinedTexts = data.predefinedTexts || {};
    
            // Se o comando foi alterado, excluímos o antigo antes de salvar o novo
            if (newCommand !== oldCommand) {
                delete predefinedTexts[oldCommand];
    
                // Atualiza o atributo `data-command` nos elementos editáveis
                document.querySelectorAll(`[data-command="${oldCommand}"]`).forEach(el => {
                    el.dataset.command = newCommand;
                });
            }
    
            // Substituímos os <br> de volta para \n antes de salvar
            predefinedTexts[newCommand] = newResponse.replace(/<br>/g, '\n');
    
            chrome.storage.local.set({ predefinedTexts }, () => {
                renderTexts(predefinedTexts); // Atualiza a interface
            });
    
            chrome.storage.sync.set({ predefinedTexts });
        });
    }
    
    


    // Monitorando a rolagem da página
window.addEventListener('scroll', () => {
    const searchIcon = document.getElementById('searchIcon');
    
    // Exibe o ícone de lupa quando a rolagem ultrapassar 100px
    if (window.scrollY > 100) {
      searchIcon.style.display = 'block';
    } else {
      searchIcon.style.display = 'none';
    }
  });
  
  // Adiciona a funcionalidade de clicar no ícone da lupa
  document.getElementById('searchIcon').addEventListener('click', () => {
    // Foca no campo de busca
    const searchInput = document.getElementById('searchInput');
    searchInput.focus();
  });
  

    // Manipula a busca
    document.getElementById('searchInput').addEventListener('input', () => {
        chrome.storage.local.get("predefinedTexts", (data) => {
            const predefinedTexts = data.predefinedTexts || {};
            renderTexts(predefinedTexts); // Atualiza a renderização de acordo com a busca
        });
    });




    
    // Adiciona novo comando
document.getElementById('textForm').addEventListener('submit', (e) => {
    e.preventDefault(); // Evita o comportamento padrão do form

    const commandInput = document.getElementById('command');
    const responseInput = document.getElementById('response');
    let command = commandInput.value.trim();
    const response = responseInput.value.trim();

    if (!command || !response) {
        alert("Comando e Resposta são obrigatórios.");
        return;
    }

    // Verifica se o comando não começa com "@" e adiciona automaticamente
    if (!command.startsWith("@")) {
        command = "@" + command; // Adiciona o "@" no início do comando
    }

    // Verifica se o comando tem no máximo 13 caracteres
    if (command.length > 13) {
        alert("O comando deve ter no máximo 13 caracteres.");
        return;
    }

    // Salva o novo comando
    chrome.storage.local.get("predefinedTexts", (data) => {
        let predefinedTexts = data.predefinedTexts || {};
        predefinedTexts[command] = response;

        chrome.storage.local.set({ predefinedTexts }, () => {
            renderTexts(predefinedTexts); // Re-renderiza após adição
        });

        chrome.storage.sync.set({ predefinedTexts });

        // Limpa os campos do formulário
        commandInput.value = '';
        responseInput.value = '';
    });
});


// Adicionar evento para o botão de configurações
document.getElementById("settingsBtn").addEventListener("click", function(event) {
    event.preventDefault();
    const menu = document.querySelector('.dropdown-menu');
    // Alternar a classe "show" para abrir/fechar o menu
    menu.classList.toggle('show');
  });
  
  // Adicionar evento para o botão de fechar (X)
  document.getElementById("closeBtn").addEventListener("click", function(event) {
    event.preventDefault();
    const menu = document.querySelector('.dropdown-menu');
    menu.classList.remove('show');
  });
  
  


    // Função para exportar os dados para JSON
    document.getElementById("exportBtn").addEventListener("click", () => {
        chrome.storage.local.get("predefinedTexts", (data) => {
            const predefinedTexts = data.predefinedTexts || {};
    
            // Criar JSON mantendo as quebras de linha
            const json = JSON.stringify(predefinedTexts, null, 2);
            const blob = new Blob([json], { type: 'application/json' });
            const url = URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = 'predefined_texts.json';
            a.click();
            URL.revokeObjectURL(url);
        });
    });
    

   // Função para importar os dados de JSON
document.getElementById("importBtn").addEventListener("click", () => {
    const fileInput = document.getElementById("importFile");
    const file = fileInput.files[0];
  
    if (file) {
      const reader = new FileReader();
      reader.onload = (event) => {
        try {
          const importedTexts = JSON.parse(event.target.result);
  
          // Obter os dados já existentes no armazenamento local
          chrome.storage.local.get("predefinedTexts", (data) => {
            const existingTexts = data.predefinedTexts || {};
  
            // Substituir ou adicionar novos comandos
            for (let command in importedTexts) {
              existingTexts[command] = importedTexts[command]; // Substituir o comando existente ou adicionar o novo
            }
  
            // Salvar os dados atualizados no armazenamento
            chrome.storage.local.set({ predefinedTexts: existingTexts }, () => {
              renderTexts(existingTexts); // Atualizar a interface com os textos atualizados
  
              // Exibir o modal de sucesso
              showModal('Importação concluída com sucesso!');
            });
  
            // Opcional: também salvar os dados no armazenamento sincronizado, se necessário
            chrome.storage.sync.set({ predefinedTexts: existingTexts });
          });
        } catch (error) {
          alert("Erro ao importar o arquivo JSON. Verifique o formato do arquivo.");
        }
      };
      reader.readAsText(file);
    } else {
      alert("Selecione um arquivo para importar.");
    }
  });
  
  // Função para mostrar o modal
  function showModal(message) {
    const modal = document.getElementById('importSuccessModal');
    const modalBody = modal.querySelector('.modal-body');
    modalBody.textContent = message;
  
    // Mostrar o modal
    modal.classList.add('show');
  }
  
  // Adicionar evento de fechar o modal ao clicar no botão de fechar
  document.getElementById("closeModalBtn").addEventListener("click", function() {
    const modal = document.getElementById('importSuccessModal');
    modal.classList.remove('show'); // Fechar o modal
  });
  


});

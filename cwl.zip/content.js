// Recupera o nome do usuário armazenado no chrome.storage
chrome.storage.local.get("userName", (data) => {
  const savedUserName = data.userName;

  // Função para obter a saudação baseada no horário
  const getSaudacao = () => {
    const hora = new Date().getHours();
    if (hora < 12) return "Bom dia";
    if (hora < 18) return "Boa tarde";
    return "Boa noite";
  };

  document.addEventListener("input", (event) => {
    const target = event.target;

    // Garante que o campo é um input ou textarea e que não está no meio de uma composição (ex: autocompletar, IME)
    if (
      target &&
      (target.tagName === "TEXTAREA" || target.tagName === "INPUT") &&
      !event.isComposing
    ) {
      let text = target.value;

      // Substitui a chave {saudacao} pelo texto adequado
      if (text.includes("{saudacao}")) {
        text = text.replace(/{saudacao}/g, getSaudacao());
      }

      // Substitui {nome} pelo nome armazenado
      if (text.includes("{nome}") && savedUserName) {
        text = text.replace(/{nome}/g, savedUserName);
      }

      // Verifica se o texto contém um comando predefinido
      chrome.storage.local.get("predefinedTexts", (data) => {
        const predefinedTexts = data.predefinedTexts || {};

        let updatedText = text; // Variável temporária para evitar loops de reescrita

        for (const command in predefinedTexts) {
          if (updatedText.includes(command)) {
            updatedText = updatedText.replace(command, predefinedTexts[command]);

            if (updatedText.includes("{saudacao}")) {
              updatedText = updatedText.replace(/{saudacao}/g, getSaudacao());
            }
            if (updatedText.includes("{nome}") && savedUserName) {
              updatedText = updatedText.replace(/{nome}/g, savedUserName);
            }
          }
        }

        // Só atualiza o campo se o texto foi realmente alterado
        if (updatedText !== text) {
          target.value = updatedText;
        }
      });
    }
  });

  // Previne que o script reescreva o texto enquanto a tecla "Backspace" ou "Delete" está pressionada
  document.addEventListener("keydown", (event) => {
    if (event.key === "Backspace" || event.key === "Delete") {
      event.target.dataset.preventChange = "true"; // Define um atributo temporário
    }
  });

  document.addEventListener("keyup", (event) => {
    if (event.key === "Backspace" || event.key === "Delete") {
      delete event.target.dataset.preventChange; // Remove o atributo quando soltar a tecla
    }
  });
});

// Recupera o nome do usuário armazenado no chrome.storage
chrome.storage.local.get('userName', (data) => {
  const savedUserName = data.userName;

  // Exibe no console o nome recuperado do chrome.storage
  //console.log("Nome recuperado do sistema:", savedUserName); // Depuração

  // Função para obter a saudação baseada no horário
  const getSaudacao = () => {
    const hora = new Date().getHours();
    if (hora < 12) return "Bom dia";
    if (hora < 18) return "Boa tarde";
    return "Boa noite";
  };

  document.addEventListener('input', (event) => {
    const target = event.target;

    // Verifique se o campo de texto foi modificado
    if (target && (target.tagName === "TEXTAREA" || target.tagName === "INPUT")) {
      let text = target.value;

      // Substitui a chave {saudacao} pelo texto adequado
      if (text.includes("{saudacao}")) {
        text = text.replace(/{saudacao}/g, getSaudacao());
      }

      // Substitui {nome} pelo nome armazenado
      if (text.includes("{nome}") && savedUserName) {
        text = text.replace(/{nome}/g, savedUserName);
        //console.log("Texto após substituição do {nome}:", text); // Depuração
      }

      // Verifica se o texto contém um comando predefinido
      chrome.storage.local.get("predefinedTexts", (data) => {
        const predefinedTexts = data.predefinedTexts || {};

        // Verifica todos os comandos predefinidos
        for (const command in predefinedTexts) {
          if (text.includes(command)) {
            // Substitui o comando pelo texto associado
            text = text.replace(command, predefinedTexts[command]);

            // Substitui a chave {saudacao} no texto do comando
            if (text.includes("{saudacao}")) {
              text = text.replace(/{saudacao}/g, getSaudacao());
            }
            if (text.includes("{nome}") && savedUserName) {
              text = text.replace(/{nome}/g, savedUserName);
              //console.log("Texto após substituição do {nome}:", text); // Depuração
            }
          }
        }

        // Atualiza o campo de texto com o texto modificado
        target.value = text;
      });
    }
  });
});

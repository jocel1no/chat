document.addEventListener('input', (event) => {
  const target = event.target;

  // Verifique se o campo de texto foi modificado
  if (target && (target.tagName === "TEXTAREA" || target.tagName === "INPUT")) {
    // Obtém o texto digitado
    let text = target.value;

    // Verifica se o texto contém um comando predefinido
    chrome.storage.local.get("predefinedTexts", (data) => {
      const predefinedTexts = data.predefinedTexts || {};

      // Verifica todos os comandos predefinidos
      for (const command in predefinedTexts) {
        if (text.includes(command)) {
          // Substitui o comando pelo texto associado
          target.value = text.replace(command, predefinedTexts[command]);
        }
      }
    });
  }
});

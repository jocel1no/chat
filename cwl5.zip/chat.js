document.addEventListener("DOMContentLoaded", function () {
    const socket = io("https://chatgac.onrender.com");
    let usuarioNome = "";
    let predefinedTexts = {};
    let mensagensExibidas = [];
    let isUserInteracting = false;
    let isConnected = false; // Flag para verificar se a conexão foi estabelecida

    // Recupera o nome do usuário do Chrome Storage
    chrome.storage.local.get("userName", function (data) {
        if (data.userName) {
            usuarioNome = data.userName;
            iniciarChat();
        }
    });

    // Recupera os pretextos do Chrome Storage
    chrome.storage.local.get("predefinedTexts", function (data) {
        predefinedTexts = data.predefinedTexts || {};
    });

    // Evento de definição do nome do usuário
    document.getElementById("definirNome").addEventListener("click", () => {
        const nomeInput = document.getElementById("nomeUsuario").value.trim();
        if (nomeInput) {
            usuarioNome = nomeInput;
            chrome.storage.local.set({ userName: usuarioNome });
            iniciarChat();
        }
    });

    // Evento de envio da mensagem
    document.getElementById("enviarBtn").addEventListener("click", enviarMensagem);

    // Detecta conexão bem-sucedida com o servidor
    socket.on("connect", function () {
        isConnected = true;
        removerMensagemAviso(); // Remove a mensagem de aviso se a conexão for estabelecida
    });

    socket.on("disconnect", function () {
        isConnected = false; // Marca como desconectado ao perder a conexão
    });

    // Função para exibir aviso caso o servidor esteja iniciando
    function exibirMensagemAviso(mensagem) {
        const chat = document.getElementById("chat");
        const aviso = document.createElement("div");
        aviso.innerText = mensagem;
        aviso.style.color = "red";
        aviso.id = "mensagemAviso";
        aviso.classList.add("mensagem-aviso");
        chat.appendChild(aviso);
    }

    // Função para remover o aviso de conexão
    function removerMensagemAviso() {
        const aviso = document.getElementById("mensagemAviso");
        if (aviso) {
            aviso.remove();
        }
    }

    // Função para iniciar o chat
    function iniciarChat() {
        document.getElementById("nomeContainer").style.display = "none";
        document.getElementById("chatContainer").style.display = "block";
        carregarMensagens();
    }

    // Função para carregar as mensagens do Chrome Storage
    function carregarMensagens() {
        chrome.storage.local.get("historicoChat", function (data) {
            const mensagens = data.historicoChat || [];
            mensagens.forEach(msg => {
                if (msg.usuario !== usuarioNome || !mensagensExibidas.includes(msg.texto)) {
                    exibirMensagem(msg.usuario, msg.texto, msg.usuario !== usuarioNome);
                    mensagensExibidas.push(msg.texto);
                }
            });
        });
    }

    // Função para exibir a mensagem no chat
    function exibirMensagem(usuario, texto, outroUsuario) {
        const chat = document.getElementById("chat");
        const div = document.createElement("div");
        div.innerHTML = outroUsuario ? `<strong>${usuario}:</strong> ${texto}` : texto;
        div.classList.add("mensagem", outroUsuario ? "outro" : "eu");
        chat.appendChild(div);
        if (!isUserInteracting) {
            chat.scrollTop = chat.scrollHeight;
        }
    }

    // Função para salvar as mensagens no Chrome Storage
    function salvarMensagemNoStorage(usuario, texto) {
        chrome.storage.local.get("historicoChat", function (data) {
            const mensagens = data.historicoChat || [];
            mensagens.push({ usuario, texto });
            chrome.storage.local.set({ historicoChat: mensagens });
        });
    }

    // Função para enviar a mensagem
    function enviarMensagem() {
        const input = document.getElementById("mensagem");
        const texto = input.value.trim();
        if (texto) {
            if (!isConnected) {
                exibirMensagemAviso("Conectando..."); // Exibe mensagem de aviso se o servidor ainda não estiver pronto
                return;
            }

            const mensagem = { usuario: usuarioNome, texto };
            socket.emit("mensagem", mensagem);
            salvarMensagemNoStorage(usuarioNome, texto);
            input.value = "";
            isUserInteracting = true;
            document.getElementById("chat").scrollTop = document.getElementById("chat").scrollHeight;
        }
    }

    // Função para exibir a caixa de pretextos ao clicar no botão @
    const arrobaBtn = document.getElementById("arrobaBtn");
    const arrobaBox = document.getElementById("arrobaBox");
    const listaArrobas = document.getElementById("listaArrobas");
    const mensagemInput = document.getElementById("mensagem");

    arrobaBtn.addEventListener("click", () => {
        arrobaBox.classList.toggle("hidden");
        atualizarListaArrobas("");
    });

    function atualizarListaArrobas(filtro) {
        listaArrobas.innerHTML = "";
        for (const command in predefinedTexts) {
            if (command.startsWith('@') && command.toLowerCase().includes(filtro.toLowerCase())) {
                const li = document.createElement("li");
                li.textContent = `${command}: ${predefinedTexts[command]}`;
                li.addEventListener("click", () => inserirArroba(command, predefinedTexts[command]));
                listaArrobas.appendChild(li);
            }
        }
    }

    document.getElementById("pesquisarArroba").addEventListener("input", (e) => {
        atualizarListaArrobas(e.target.value);
    });

    function inserirArroba(command, pretexto) {
        mensagemInput.value += `${command}: ${pretexto} `;
        arrobaBox.classList.add("hidden");
    }

    socket.on("mensagem", function (mensagem) {
        exibirMensagem(mensagem.usuario, mensagem.texto, mensagem.usuario !== usuarioNome);
        salvarMensagemNoStorage(mensagem.usuario, mensagem.texto);
    });

    document.getElementById("chat").addEventListener("scroll", function () {
        const chat = document.getElementById("chat");
        const scrollHeight = chat.scrollHeight;
        const scrollTop = chat.scrollTop;
        const clientHeight = chat.clientHeight;

        isUserInteracting = scrollHeight - scrollTop !== clientHeight;
    });

    // Evento para enviar a mensagem ao pressionar Enter
document.getElementById("mensagem").addEventListener("keypress", function (event) {
    if (event.key === "Enter") {
        event.preventDefault(); // Impede a quebra de linha no input
        enviarMensagem(); // Chama a função de envio da mensagem
    }
});

});

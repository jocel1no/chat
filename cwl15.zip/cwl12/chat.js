document.addEventListener("DOMContentLoaded", function () {
    // Seletores do DOM (cache)
    const loginSection = document.getElementById("login-section");
    const loginForm = document.getElementById("login-form");
    const nomeUsuarioInput = document.getElementById("nomeUsuarioInput");
    const definirNomeBtn = document.getElementById("definirNomeBtn");

    const chatSection = document.getElementById("chat-section");
    const chatMessages = document.getElementById("chat-messages");
    const connectionStatus = document.getElementById("connection-status");

    const messageForm = document.getElementById("message-form");
    const mensagemInput = document.getElementById("mensagemInput");
    const enviarBtn = document.getElementById("enviarBtn");
    const arrobaBtn = document.getElementById("arrobaBtn");

    const modalArroba = document.getElementById("modalArroba");
    const closeModalBtn = document.getElementById("closeModalBtn");
    const pesquisarArrobaInput = document.getElementById("pesquisarArrobaInput");
    const listaArrobas = document.getElementById("listaArrobas");

    // Estado da aplicação
    let usuarioNome = "";
    let predefinedTexts = {};
    let isUserScrolling = false;
    let isConnected = false;
    const socket = io("https://chatgac.onrender.com"); // Mova a inicialização para cá

    // --- Funções ---

    // Formata e exibe a mensagem no chat
    function exibirMensagem(usuario, texto, timestamp = new Date()) {
        const msgDiv = document.createElement("div");
        msgDiv.classList.add("message");

        const isMyMessage = usuario === usuarioNome;
        msgDiv.classList.add(isMyMessage ? "my-message" : "other-message");

        // Adiciona o remetente (apenas para mensagens de outros)
        if (!isMyMessage) {
            const senderSpan = document.createElement("span");
            senderSpan.classList.add("sender");
            senderSpan.textContent = usuario;
            msgDiv.appendChild(senderSpan);
        }

        // Adiciona o texto da mensagem
        const textSpan = document.createElement("span");
        textSpan.textContent = texto; // Use textContent para evitar XSS
        msgDiv.appendChild(textSpan);

        // Adiciona o timestamp
        const timeSpan = document.createElement("span");
        timeSpan.classList.add("timestamp");
        timeSpan.textContent = timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
        msgDiv.appendChild(timeSpan);

        chatMessages.appendChild(msgDiv);

        // Auto-scroll apenas se o usuário não estiver rolando para cima
        if (!isUserScrolling) {
            scrollToBottom();
        }
    }

    // Exibe mensagem do sistema (conexão, etc.)
    function exibirMensagemSistema(texto) {
        // Remove status de conexão anterior se houver
        if (connectionStatus && connectionStatus.parentNode) {
            connectionStatus.parentNode.removeChild(connectionStatus);
        }
        // Ou atualiza uma div existente
        const systemDiv = document.createElement("div");
        systemDiv.classList.add("system-message");
        systemDiv.textContent = texto;
        chatMessages.appendChild(systemDiv);
        scrollToBottom();
    }


    // Rola o chat para o final
    function scrollToBottom() {
        chatMessages.scrollTop = chatMessages.scrollHeight;
    }

    // Salva mensagem no Chrome Storage
    function salvarMensagemNoStorage(usuario, texto, timestamp = new Date()) {
        chrome.storage.local.get("historicoChat", function (data) {
            const mensagens = data.historicoChat || [];
            // Limitar histórico se necessário (ex: últimas 100 mensagens)
            // while (mensagens.length > 100) {
            //     mensagens.shift();
            // }
            mensagens.push({ usuario, texto, timestamp: timestamp.toISOString() }); // Salva como ISO string
            chrome.storage.local.set({ historicoChat: mensagens });
        });
    }

    // Carrega mensagens do Chrome Storage
    function carregarMensagens() {
        chrome.storage.local.get("historicoChat", function (data) {
            const mensagens = data.historicoChat || [];
            chatMessages.innerHTML = ''; // Limpa mensagens existentes antes de carregar
            // Adiciona a mensagem de status inicial novamente
            if (connectionStatus) chatMessages.appendChild(connectionStatus);

            mensagens.forEach(msg => {
                // Converte timestamp de volta para Date object
                exibirMensagem(msg.usuario, msg.texto, new Date(msg.timestamp));
            });
            scrollToBottom(); // Rola para o final após carregar
        });
    }

    // Inicia o chat após definir o nome
    function iniciarChat() {
        loginSection.classList.add("hidden");
        chatSection.classList.remove("hidden");
        carregarMensagens();
        mensagemInput.focus(); // Foca no input de mensagem
    }

    // Envia a mensagem
    function enviarMensagem() {
        const texto = mensagemInput.value.trim();
        if (texto && isConnected) {
            const timestamp = new Date();
            const mensagem = { usuario: usuarioNome, texto };

            socket.emit("mensagem", mensagem); // Envia para o servidor
            exibirMensagem(usuarioNome, texto, timestamp); // Exibe localmente imediatamente
            salvarMensagemNoStorage(usuarioNome, texto, timestamp); // Salva no storage

            mensagemInput.value = ""; // Limpa o input
            isUserScrolling = false; // Reseta o scroll para permitir auto-scroll
            scrollToBottom(); // Garante que a própria mensagem role a tela
        } else if (!isConnected) {
            console.warn("Tentativa de enviar mensagem sem conexão.");
            // Poderia exibir um aviso mais explícito para o usuário aqui
        }
    }

    // Atualiza a lista de @ comandos no modal
    function atualizarListaArrobas(filtro) {
        listaArrobas.innerHTML = ""; // Limpa a lista
        const filtroLowerCase = filtro.toLowerCase();

        for (const command in predefinedTexts) {
            if (command.startsWith('@')) {
                const textLowerCase = predefinedTexts[command].toLowerCase();
                const commandLowerCase = command.toLowerCase();

                if (commandLowerCase.includes(filtroLowerCase) || textLowerCase.includes(filtroLowerCase)) {
                    const li = document.createElement("li");
                    // Exibe comando e uma prévia do texto
                    let previewText = predefinedTexts[command];
                    if (previewText.length > 50) {
                         previewText = previewText.substring(0, 47) + "...";
                    }
                    li.textContent = `${command}: ${previewText}`;
                    li.dataset.command = command; // Guarda o comando completo no dataset
                    li.dataset.text = predefinedTexts[command]; // Guarda o texto completo
                    li.addEventListener("click", () => inserirArroba(li.dataset.command, li.dataset.text));
                    listaArrobas.appendChild(li);
                }
            }
        }
    }

    // Insere o comando @ selecionado no input de mensagem
    function inserirArroba(command, pretexto) {
        mensagemInput.value += `${pretexto} `; // Insere apenas o texto, não o comando @
        modalArroba.classList.add("hidden");
        mensagemInput.focus(); // Foca de volta no input
    }

    // --- Lógica Inicial e Event Listeners ---

    // 1. Tenta recuperar nome e pretextos do storage
    chrome.storage.local.get(["userName", "predefinedTexts"], function (data) {
        if (data.userName) {
            usuarioNome = data.userName;
            iniciarChat(); // Se já tem nome, inicia o chat direto
        } else {
            loginSection.classList.remove("hidden"); // Mostra login se não tem nome
            nomeUsuarioInput.focus();
        }
        predefinedTexts = data.predefinedTexts || {};
    });

    // 2. Listener para definir o nome (submit do form de login)
    loginForm.addEventListener("submit", (e) => {
        e.preventDefault(); // Impede recarregamento da página
        const nomeInput = nomeUsuarioInput.value.trim();
        if (nomeInput) {
            usuarioNome = nomeInput;
            chrome.storage.local.set({ userName: usuarioNome }, () => {
                iniciarChat();
            });
        }
    });

    // 3. Listeners de Conexão Socket.IO
    socket.on("connect", () => {
        console.log("Conectado ao servidor Socket.IO");
        isConnected = true;
        if (connectionStatus) connectionStatus.textContent = "Conectado!";
        // Habilita os inputs/botões do chat
        mensagemInput.disabled = false;
        enviarBtn.disabled = false;
        // Esconde a mensagem de conectado após um tempo
        setTimeout(() => {
            if (connectionStatus && connectionStatus.textContent === "Conectado!") {
                 connectionStatus.classList.add('hidden'); // Ou remove o elemento
            }
        }, 3000);
    });

    socket.on("disconnect", () => {
        console.warn("Desconectado do servidor Socket.IO");
        isConnected = false;
        if (connectionStatus) {
             connectionStatus.textContent = "Desconectado. Tentando reconectar...";
             connectionStatus.classList.remove('hidden');
        }
        // Desabilita os inputs/botões do chat
        mensagemInput.disabled = true;
        enviarBtn.disabled = true;
    });

    socket.on("connect_error", (err) => {
        console.error("Erro de conexão:", err);
        isConnected = false;
        if (connectionStatus) {
             connectionStatus.textContent = "Falha ao conectar. Verifique o servidor.";
             connectionStatus.classList.remove('hidden');
        }
         mensagemInput.disabled = true;
         enviarBtn.disabled = true;
    });


    // 4. Listener para receber mensagens do servidor
    socket.on("mensagem", (mensagem) => {
        // Evita exibir a própria mensagem duplicada se o servidor ecoar
        // (Assumindo que o servidor não envia a mensagem de volta para quem mandou)
        // Se o servidor envia de volta, você precisa de uma lógica para não exibir aqui.
        if (mensagem.usuario !== usuarioNome) {
             const timestamp = new Date(); // Usa o tempo de recebimento
             exibirMensagem(mensagem.usuario, mensagem.texto, timestamp);
             // Só salva no storage se não for a própria mensagem (já salva no envio)
             salvarMensagemNoStorage(mensagem.usuario, mensagem.texto, timestamp);
        }
    });

    // 5. Listener para enviar mensagem (submit do form de mensagem)
    messageForm.addEventListener("submit", (e) => {
        e.preventDefault(); // Impede recarregamento da página
        enviarMensagem();
    });

    // 6. Listener de scroll no chat para controlar o auto-scroll
    chatMessages.addEventListener("scroll", () => {
        // Verifica se o scroll NÃO está no final (com uma pequena margem)
        const threshold = 10; // Margem em pixels
        isUserScrolling = chatMessages.scrollTop + chatMessages.clientHeight < chatMessages.scrollHeight - threshold;
    });

    // 7. Listeners para o Modal de Comandos '@'
    arrobaBtn.addEventListener("click", () => {
        atualizarListaArrobas(''); // Mostra todos ao abrir
        modalArroba.classList.remove("hidden");
        pesquisarArrobaInput.focus();
    });

    closeModalBtn.addEventListener("click", () => {
        modalArroba.classList.add("hidden");
    });

    // Fecha o modal se clicar fora do conteúdo dele
    modalArroba.addEventListener("click", (e) => {
        if (e.target === modalArroba) { // Clicou no fundo escuro
            modalArroba.classList.add("hidden");
        }
    });

    pesquisarArrobaInput.addEventListener("input", (e) => {
        atualizarListaArrobas(e.target.value);
    });

});
document.addEventListener('DOMContentLoaded', () => {
    let currentSymbol = '@'; // Variável global

    // --- Pegar Referências aos Elementos ---
    const toggleSymbolBtn = document.getElementById('toggleSymbolBtn');
    const symbolDisplay = document.getElementById('symbolDisplay'); // Span dentro do form no dropdown
    const nameModal = document.getElementById('nameModal');
    const userNameInput = document.getElementById('userNameInput');
    const saveNameBtn = document.getElementById('saveNameBtn');
    const userNameDisplay = document.getElementById('userNameDisplay');
    const userNameText = document.getElementById('userNameText');
    const editUserName = document.getElementById('editUserName');
    const searchInput = document.getElementById('searchInput');
    const textListDiv = document.getElementById('textList');
    const settingsBtn = document.getElementById('settingsBtn'); // Botão da engrenagem
    const settingsMenu = document.querySelector('.dropdown-menu[aria-labelledby="settingsBtn"]'); // O menu/modal
    const closeSettingsBtn = document.getElementById('closeBtn'); // Botão 'X' dentro do menu/modal
    const importSuccessModal = document.getElementById('importSuccessModal');
    const closeModalBtn = document.getElementById('closeModalBtn'); // Botão 'X' do modal de sucesso
    const importBtn = document.getElementById('importBtn'); // Botão Online Import no header
    const importLocalBtn = document.getElementById('importLocalBtn'); // Botão Local Import no header
    const exportBtn = document.getElementById('exportBtn'); // Botão Exportar no dropdown
    const importFile = document.getElementById('importFile'); // Input file escondido
    const textForm = document.getElementById('textForm'); // Formulário no dropdown
    const searchIcon = document.getElementById('searchIcon'); // Ícone flutuante
    const commandInput = document.getElementById('command'); // Input do comando no form
    const responseInput = document.getElementById('response'); // Textarea da resposta no form

    // --- Validação de Elementos Essenciais ---
    // Adicione verificações para elementos críticos se necessário
    if (!settingsBtn || !settingsMenu || !closeSettingsBtn || !textForm || !symbolDisplay) {
        console.error("ERRO CRÍTICO: Elementos essenciais do HTML (settingsBtn, dropdown-menu, closeBtn, textForm, symbolDisplay) não encontrados. Funcionalidades podem falhar.");
        // return; // Descomente para parar a execução se elementos críticos faltarem
    }

    // === Lógica do Modal de Configurações (Engrenagem) ===

    function openSettingsModal() {
        if (settingsMenu && !settingsMenu.classList.contains('show')) {
            settingsMenu.classList.add('show');
            // Adiciona classe ao body para CSS (ex: travar scroll)
            document.body.classList.add('settings-modal-open');
        }
    }

    function closeSettingsModal() {
        if (settingsMenu && settingsMenu.classList.contains('show')) {
            settingsMenu.classList.remove('show');
            // Remove classe do body
            document.body.classList.remove('settings-modal-open');
        }
    }

    // Abrir/Fechar no Botão da Engrenagem
    if (settingsBtn) {
        settingsBtn.addEventListener("click", function(event) {
            event.preventDefault();
            event.stopPropagation(); // Impede fechar imediatamente pelo 'click outside'
            if (settingsMenu.classList.contains('show')) {
                closeSettingsModal();
            } else {
                openSettingsModal();
            }
        });
    } else {
         console.error("Botão #settingsBtn não encontrado.");
    }

    // Fechar no Botão 'X' Interno
    if (closeSettingsBtn) {
        closeSettingsBtn.addEventListener("click", function(event) {
            event.preventDefault();
            closeSettingsModal();
        });
    } else {
         console.error("Botão #closeBtn não encontrado.");
    }


    // Fechar com a Tecla 'Esc'
    window.addEventListener('keydown', function(event) {
        if (event.key === 'Escape' || event.key === 'Esc') {
            // Fecha modal de configurações se estiver aberto
            if (settingsMenu && settingsMenu.classList.contains('show')) {
                closeSettingsModal();
            }
            // Fecha outros modais se estiverem abertos (exemplo)
            if (nameModal && nameModal.style.display === 'block') {
                 nameModal.style.display = 'none';
            }
             if (importSuccessModal && importSuccessModal.classList.contains('show')) {
                 importSuccessModal.classList.remove('show');
            }
        }
    });

    // Fechar ao Clicar Fora do Modal de Configurações
     window.addEventListener('click', function(event) {
        if (settingsMenu && settingsMenu.classList.contains('show')) {
            // Garante que o clique não foi no botão que abre E não foi dentro do menu
            if (settingsBtn && !settingsBtn.contains(event.target) && !settingsMenu.contains(event.target)) {
                 closeSettingsModal();
             }
         }
     });

     // Impede que cliques DENTRO do menu de configurações fechem ele
     if (settingsMenu) {
         settingsMenu.addEventListener('click', function(event) {
             event.stopPropagation();
         });
     } else {
          console.error("Elemento .dropdown-menu não encontrado para adicionar stopPropagation.");
     }

    // === Fim da Lógica do Modal de Configurações ===


    // === Lógica de Nome de Usuário ===
    // Verifica se o nome já está salvo no chrome.storage
     if (userNameText && userNameDisplay && nameModal) { // Verifica se elementos existem
         chrome.storage.local.get('userName', (data) => {
             const savedUserName = data.userName;
             if (savedUserName) {
                 userNameText.textContent = `Bem-vindo, ${savedUserName}!`;
                 userNameDisplay.style.display = 'flex'; // Usa 'flex' como no HTML
             } else {
                  userNameDisplay.style.display = 'none'; // Esconde se não tiver nome
                 nameModal.style.display = 'block';
             }
         });
     } else {
          console.error("Elementos do nome de usuário não encontrados.");
     }


    // Evento para abrir o modal ao clicar no lápis
     if (editUserName && nameModal && userNameInput) {
         editUserName.addEventListener('click', () => {
             nameModal.style.display = 'block';
             chrome.storage.local.get('userName', (data) => {
                 userNameInput.value = data.userName || ''; // Preenche ou deixa vazio
             });
         });
     } else {
          console.error("Elementos para editar nome não encontrados.");
     }


    // Evento para salvar o nome
     if (saveNameBtn && userNameInput && userNameText && userNameDisplay && nameModal) {
         saveNameBtn.addEventListener('click', () => {
             const userName = userNameInput.value.trim();
             if (userName) {
                 chrome.storage.local.set({ userName: userName }, () => {
                     userNameText.textContent = `Bem-vindo, ${userName}!`;
                     userNameDisplay.style.display = 'flex'; // Usa flex
                     nameModal.style.display = 'none';
                 });
             } else {
                 alert("Por favor, insira seu nome.");
             }
         });
     } else {
          console.error("Elementos para salvar nome não encontrados.");
     }

    // === Fim da Lógica de Nome ===


    // === Lógica de Símbolo e Textos ===

    // Alternar entre @ e #
     if (toggleSymbolBtn && symbolDisplay) {
         toggleSymbolBtn.addEventListener('click', () => {
             currentSymbol = currentSymbol === '@' ? '#' : '@';
             toggleSymbolBtn.textContent = `${currentSymbol}`; // Mostra só o símbolo no botão
             toggleSymbolBtn.setAttribute('title', `Alternar símbolo (Atual: ${currentSymbol})`); // Atualiza tooltip
              if(symbolDisplay) { // Verifica se o span do form existe
                 symbolDisplay.textContent = currentSymbol;
             }
             loadTexts();
         });
          // Define o texto/tooltip inicial do botão
         toggleSymbolBtn.textContent = `${currentSymbol}`;
          toggleSymbolBtn.setAttribute('title', `Alternar símbolo (Atual: ${currentSymbol})`);
     } else {
          console.error("Botão #toggleSymbolBtn ou span #symbolDisplay não encontrado.");
     }


    // Carregar os textos
    function loadTexts() {
        chrome.storage.local.get("predefinedTexts", (data) => {
            const predefinedTexts = data.predefinedTexts || {};
            const filteredTexts = {};
            for (const command in predefinedTexts) {
                if (command.startsWith(currentSymbol)) {
                    filteredTexts[command] = predefinedTexts[command];
                }
            }
            renderTexts(filteredTexts); // Chama renderização
        });
    }

    // Renderizar os textos na lista (estrutura .card)
    function renderTexts(texts) {
        if (!searchInput || !textListDiv) return; // Sai se elementos não existem

        const searchQuery = searchInput.value.toLowerCase();
        textListDiv.innerHTML = ''; // Limpa lista

        const commandsToRender = Object.keys(texts).filter(command => {
            const text = texts[command];
            return command.toLowerCase().includes(searchQuery) || text.toLowerCase().includes(searchQuery);
        });

        if (commandsToRender.length === 0) {
             textListDiv.innerHTML = '<p class="text-center text-muted mt-3">Nenhum comando encontrado.</p>';
             return;
        }


        commandsToRender.forEach(command => {
            const text = texts[command];
            const textDiv = document.createElement('div');
            // Usa classes Bootstrap + 'equal-width' se o CSS depender dela
            textDiv.classList.add('card', 'mb-3'); // Removido 'equal-width' por enquanto, CSS controla
            textDiv.innerHTML = `
                <div class="card-body">
                    <h5 class="card-title">
                        <strong contenteditable="true" class="edit-command" data-command="${command}" title="Clique para editar comando">${command}</strong>
                    </h5>
                    <p class="card-text">
                        <span contenteditable="true" class="edit-response" data-command="${command}" title="Clique para editar resposta">${text.replace(/\n/g, '<br>')}</span>
                    </p>
                    <div class="card-actions mt-2 text-end"> <button class="btn btn-sm btn-info shareBtn" data-command="${command}" title="Compartilhar Comando">
                            <i class="fas fa-share-alt"></i> <span class="d-none d-md-inline">Compartilhar</span>
                        </button>
                        <button class="btn btn-sm btn-danger deleteBtn" data-command="${command}" title="Excluir Comando">
                            <i class="fas fa-trash"></i> <span class="d-none d-md-inline">Excluir</span>
                        </button>
                    </div>
                </div>`;
            textListDiv.appendChild(textDiv);
        });

        addEditAndDeleteEvents(); // Adiciona listeners para editar/deletar
        addShareEvent(); // Adiciona listener para compartilhar
    }

    // Função para adicionar evento de Compartilhar
    function addShareEvent() {
        document.querySelectorAll('.shareBtn').forEach(button => {
            // Remove listener antigo para evitar duplicação
             button.removeEventListener('click', handleShareClick);
             // Adiciona novo listener
            button.addEventListener('click', handleShareClick);
        });
    }
     // Handler separado para clique de compartilhar
     async function handleShareClick(e) {
         const button = e.currentTarget; // Usar currentTarget é mais seguro
         const command = button.dataset.command;
         const responseElement = document.querySelector(`.edit-response[data-command="${command}"]`);
         if (!responseElement) return;

          const response = responseElement.innerText.trim();
         const jsonData = { [command]: response };

          // Feedback visual no botão Share
         const originalShareHtml = button.innerHTML;
         button.disabled = true;
         button.innerHTML = '<i class="fas fa-spinner fa-spin fa-fw"></i>';

         try {
             const res = await fetch('https://server-kvy1.onrender.com/salvar-json', { // URL do seu backend
                 method: 'PUT',
                 headers: { 'Content-Type': 'application/json' },
                 body: JSON.stringify(jsonData)
             });

             if (res.ok) {
                 alert(`Comando '${command}' compartilhado com sucesso!`); // Ou usar showModal
             } else {
                 alert(`Erro ao compartilhar '${command}'. Status: ${res.status}`); // Ou usar showModal
             }
         } catch (error) {
             alert('Erro de rede ao tentar compartilhar. Verifique sua conexão.'); // Ou usar showModal
             console.error('Share Error:', error);
         } finally {
             // Restaura botão Share
             button.disabled = false;
             button.innerHTML = originalShareHtml;
         }
     }


    // Adiciona eventos de edição e exclusão
    function addEditAndDeleteEvents() {
        // Edição (blur)
        document.querySelectorAll('.edit-command, .edit-response').forEach((editable) => {
            // Remove listener antigo para evitar duplicação
             editable.removeEventListener('blur', handleEditBlur);
             // Adiciona novo listener
            editable.addEventListener('blur', handleEditBlur);
        });

        // Exclusão (click)
        document.querySelectorAll('.deleteBtn').forEach((btn) => {
             // Remove listener antigo para evitar duplicação
             btn.removeEventListener('click', handleDeleteClick);
             // Adiciona novo listener
             btn.addEventListener('click', handleDeleteClick);
        });
    }
     // Handler separado para edição (blur)
     function handleEditBlur(e) {
         const targetElement = e.target;
         const oldCommand = targetElement.dataset.command;
         if (!oldCommand) return;

          // Encontra os elementos relativos ao comando que perdeu o foco
         const commandElement = textListDiv.querySelector(`.edit-command[data-command="${oldCommand}"]`);
         const responseElement = textListDiv.querySelector(`.edit-response[data-command="${oldCommand}"]`);

          if (!commandElement || !responseElement) return; // Segurança

          const newCommand = commandElement.innerText.trim();
          // Converte <br> de volta para \n corretamente
         const newResponse = responseElement.innerHTML.replace(/<br\s*\/?>/gi, '\n').trim();

          // Validação básica
         if (!newCommand.startsWith(currentSymbol)) {
             alert(`O comando deve começar com '${currentSymbol}'. Alteração não salva.`);
             // Restaura visualmente se necessário (pega do storage ou variável) - Opcional complexo
             loadTexts(); // Recarrega tudo como fallback simples
             return;
         }
         // Compara com a versão salva antes de salvar para evitar saves desnecessários? (Opcional)

          saveText(newCommand, newResponse, oldCommand); // Chama saveText
     }

      // Handler separado para exclusão (click)
     function handleDeleteClick(e) {
          const button = e.currentTarget;
         const command = button.dataset.command;
         if (command && confirm(`Tem certeza que deseja excluir o comando "${command}"?`)) {
             chrome.storage.local.get("predefinedTexts", (data) => {
                 let predefinedTexts = data.predefinedTexts || {};
                 if (predefinedTexts[command]) {
                     delete predefinedTexts[command];
                     chrome.storage.local.set({ predefinedTexts }, () => {
                         console.log(`Comando "${command}" excluído.`);
                         loadTexts(); // Recarrega a lista
                     });
                 }
             });
         }
     }


    // Salva texto (novo ou editado)
    function saveText(newCommand, newResponse, oldCommand = "") {
        if (!newCommand.startsWith(currentSymbol)) {
            alert(`O comando deve começar com '${currentSymbol}'.`);
            return;
        }

        chrome.storage.local.get("predefinedTexts", (data) => {
            let predefinedTexts = data.predefinedTexts || {};
            let commandExists = false;

            // Verifica conflito (exceto se for o próprio comando sendo renomeado para si mesmo)
             for (let existingCommand in predefinedTexts) {
                 if (newCommand === existingCommand && newCommand !== oldCommand) {
                     commandExists = true;
                     break;
                 }
                 // Adicionar verificação de prefixo semelhante se desejado
                 // if (newCommand !== oldCommand && hasSimilarPrefix(newCommand, existingCommand)) { ... }
             }

             if(commandExists) {
                 alert(`O comando '${newCommand}' já existe. Escolha outro nome.`);
                 loadTexts(); // Recarrega para reverter a edição visual
                 return;
             }


            // Se está renomeando (oldCommand existe e é diferente do novo)
            if (oldCommand && newCommand !== oldCommand) {
                 // Verifica se o comando antigo realmente existe antes de deletar
                 if (predefinedTexts.hasOwnProperty(oldCommand)) {
                     delete predefinedTexts[oldCommand];
                     console.log(`Comando antigo "${oldCommand}" removido para renomear para "${newCommand}".`);
                 }
            }

            // Adiciona/Atualiza o comando
            predefinedTexts[newCommand] = newResponse; // Salva resposta com \n

            chrome.storage.local.set({ predefinedTexts }, () => {
                console.log(`Comando "${newCommand}" salvo/atualizado.`);
                // Só recarrega se não for uma adição (que já limpa e recarrega)
                 if(oldCommand) {
                    loadTexts();
                 }
            });
        });
    }

    // Submissão do formulário de novo comando
    if (textForm) {
        textForm.addEventListener('submit', (e) => {
            e.preventDefault();

            if (!commandInput || !responseInput) return; // Verifica inputs

            let commandValue = commandInput.value.trim();
            const responseValue = responseInput.value.trim();

            if (!commandValue || !responseValue) {
                alert("Comando e Texto de Resposta são obrigatórios.");
                return;
            }

            if (!commandValue.startsWith(currentSymbol)) {
                commandValue = currentSymbol + commandValue;
            }

            chrome.storage.local.get("predefinedTexts", (data) => {
                let predefinedTexts = data.predefinedTexts || {};

                if (predefinedTexts.hasOwnProperty(commandValue)) {
                    alert(`O comando '${commandValue}' já existe.`);
                    return;
                }
                // Adicionar verificação de prefixo semelhante se desejado
                // for (let existingCommand in predefinedTexts) { ... }


                predefinedTexts[commandValue] = responseValue;

                chrome.storage.local.set({ predefinedTexts }, () => {
                    console.log(`Novo comando "${commandValue}" adicionado.`);
                    loadTexts(); // Recarrega a lista
                    commandInput.value = ''; // Limpa form
                    responseInput.value = '';
                    // Fecha o modal de configurações após salvar?
                    // closeSettingsModal(); // Descomente se quiser fechar
                });
            });
        });
    } else {
         console.error("Formulário #textForm não encontrado.");
    }


    // Função de verificação de prefixo semelhante (opcional)
    // function hasSimilarPrefix(command1, command2) { ... }

    // === Fim da Lógica de Símbolo e Textos ===


    // === Lógica de Scroll e Ícone de Busca ===
    if (searchIcon && searchInput) {
         window.addEventListener('scroll', () => {
             if (window.scrollY > 100) {
                 searchIcon.style.display = 'flex'; // Mostra com flex
             } else {
                 searchIcon.style.display = 'none'; // Esconde
             }
         });

          searchIcon.addEventListener('click', () => {
             searchInput.focus();
              // Opcional: Rolar para o topo suavemente
              window.scrollTo({ top: 0, behavior: 'smooth' });
         });
     } else {
          console.warn("Ícone de busca flutuante ou input de busca não encontrados.");
     }
     // === Fim da Lógica de Scroll ===


    // === Lógica de Busca ===
    if (searchInput) {
        searchInput.addEventListener('input', () => {
            // A lógica de busca existente parece OK, apenas garante que renderTexts é chamado
            loadTexts(); // Recarrega e filtra baseado no input
             // O ideal seria ter uma função de filtro separada para não recarregar do storage sempre
             // Mas para simplificar, manter loadTexts() que chama renderTexts() com filtro
        });
    }

    // === Lógica de Importação/Exportação ===

    // Exportação
     if (exportBtn) {
         exportBtn.addEventListener("click", () => {
             chrome.storage.local.get("predefinedTexts", (data) => {
                 const predefinedTexts = data.predefinedTexts || {};
                 const filteredTexts = Object.fromEntries(
                     Object.entries(predefinedTexts).filter(([key]) => key.startsWith('#') || key.startsWith('@'))
                 );

                 if (Object.keys(filteredTexts).length === 0) {
                     alert("Não há comandos (@ ou #) para exportar.");
                     return;
                 }

                 const json = JSON.stringify(filteredTexts, null, 2);
                 const blob = new Blob([json], { type: 'application/json' });
                 const url = URL.createObjectURL(blob);
                 const a = document.createElement('a');
                 a.href = url;
                 a.download = 'predefined_texts.json';
                 document.body.appendChild(a); // Necessário em alguns navegadores
                 a.click();
                 document.body.removeChild(a);
                 URL.revokeObjectURL(url);
                  // Opcional: Fechar modal de config após exportar?
                  // closeSettingsModal();
             });
         });
     } else {
         console.error("Botão #exportBtn não encontrado.");
     }


    // Importação Online
    if (importBtn) {
        importBtn.addEventListener("click", async () => {
             console.log("[Import Online] Listener iniciado.");
             const onlineImportButton = document.getElementById('importBtn'); // Botão do header
             let originalButtonHtml = '';

             if (onlineImportButton) {
                 console.log("[Import Online] Botão existe. Tentando mudar estado...");
                 try {
                     originalButtonHtml = onlineImportButton.innerHTML;
                     onlineImportButton.disabled = true;
                     onlineImportButton.innerHTML = '<i class="fas fa-spinner fa-spin fa-fw"></i> Carregando...';
                     onlineImportButton.offsetHeight; // Force reflow
                     console.log("[Import Online] innerHTML do botão alterado para spinner.");
                 } catch (e) {
                     console.error("[Import Online] Erro ao tentar alterar o botão:", e);
                 }
             } else {
                 console.error("[Import Online] Botão #importBtn não encontrado!");
                 return;
             }

             try {
                 console.log("[Import Online] Limpando cache...");
                 await caches.keys().then(names => { for (let name of names) caches.delete(name); });
                 console.log("[Import Online] Cache limpo.");

                 const jsonUrl = `https://jocel1no.github.io/chat/pretextos.json?t=${Date.now()}`;
                 console.log("[Import Online] Fetching:", jsonUrl);

                 const response = await fetch(jsonUrl, { cache: "no-store" });
                 console.log("[Import Online] Fetch status:", response.status);

                 if (!response.ok) throw new Error(`Erro ${response.status}: ${response.statusText}`);

                 const importedTexts = await response.json();
                 console.log("[Import Online] JSON recebido:", importedTexts ? 'OK' : 'Inválido/Nulo');

                 if (typeof importedTexts !== 'object' || importedTexts === null) throw new Error("Formato JSON importado inválido.");

                 console.log("[Import Online] Obtendo textos existentes do storage...");
                 chrome.storage.local.get("predefinedTexts", (data) => {
                     console.log("[Import Online] Textos existentes obtidos.");
                     const existingTexts = data.predefinedTexts || {};
                     let updatedCount = 0;

                     for (let command in importedTexts) {
                         if ((command.startsWith('#') || command.startsWith('@')) && typeof importedTexts[command] === 'string') {
                             if (!existingTexts.hasOwnProperty(command) || existingTexts[command] !== importedTexts[command]){
                                 updatedCount++;
                             }
                             existingTexts[command] = importedTexts[command];
                         }
                     }
                     console.log(`[Import Online] Comandos processados: ${updatedCount} adicionados/atualizados.`);

                     console.log("[Import Online] Salvando no storage...");
                     chrome.storage.local.set({ predefinedTexts: existingTexts }, () => {
                         console.log("[Import Online] Salvo no storage. Recarregando textos e mostrando modal...");
                         loadTexts();

                         let successMsg = "Importação online concluída!";
                         if (updatedCount > 0) successMsg += ` ${updatedCount} comandos adicionados/atualizados.`;
                         else successMsg += ` Nenhum comando novo ou modificado encontrado.`;
                         showModal(successMsg);
                         console.log("[Import Online] Modal de sucesso mostrado.");

                         // Restaura botão APÓS sucesso
                         if (onlineImportButton) {
                             console.log("[Import Online] Restaurando botão (Sucesso).");
                             onlineImportButton.disabled = false;
                             onlineImportButton.innerHTML = originalButtonHtml;
                         }
                     });
                 });

             } catch (error) {
                  console.error("[Import Online] ERRO CAPTURADO:", error);
                  alert(`Erro na importação: ${error.message}`);
                 if (onlineImportButton) {
                     console.log("[Import Online] Restaurando botão (Erro).");
                     onlineImportButton.disabled = false;
                     onlineImportButton.innerHTML = originalButtonHtml;
                 }
             }
        });
    } else {
         console.error("Botão #importBtn não encontrado.");
    }


    // Importação Local
    if (importLocalBtn && importFile) {
        importLocalBtn.addEventListener("click", () => {
             console.log("Botão Importar Local clicado, acionando #importFile.");
             importFile.click();
        });

         importFile.addEventListener("change", (event) => {
             const file = event.target.files[0];
             console.log("Arquivo selecionado:", file ? file.name : 'Nenhum');

             if (file) {
                 const reader = new FileReader();
                 reader.onload = (e) => {
                     try {
                         const importedTexts = JSON.parse(e.target.result);
                         console.log("Arquivo lido e parseado.");

                         if (typeof importedTexts !== 'object' || importedTexts === null) {
                              throw new Error("Formato JSON inválido.");
                         }


                         chrome.storage.local.get("predefinedTexts", (data) => {
                             const existingTexts = data.predefinedTexts || {};
                             let updatedCount = 0;

                             for (let command in importedTexts) {
                                 if ((command.startsWith('#') || command.startsWith('@')) && typeof importedTexts[command] === 'string') {
                                      if (!existingTexts.hasOwnProperty(command) || existingTexts[command] !== importedTexts[command]){
                                         updatedCount++;
                                     }
                                     existingTexts[command] = importedTexts[command];
                                 }
                             }
                              console.log(`Importação Local: ${updatedCount} comandos adicionados/atualizados.`);


                             chrome.storage.local.set({ predefinedTexts: existingTexts }, () => {
                                 loadTexts();
                                  let successMsg = "Importação local concluída!";
                                 if (updatedCount > 0) successMsg += ` ${updatedCount} comandos adicionados/atualizados.`;
                                 else successMsg += ` Nenhum comando novo ou modificado encontrado.`;
                                 showModal(successMsg);
                                  // Limpa o valor do input file para permitir importar o mesmo arquivo novamente
                                 event.target.value = '';
                             });
                         });
                     } catch (error) {
                          console.error("Erro ao processar JSON importado localmente:", error);
                         alert(`Erro ao importar arquivo: ${error.message}`);
                          event.target.value = ''; // Limpa mesmo em caso de erro
                     }
                 };
                  reader.onerror = () => {
                      alert("Ocorreu um erro ao tentar ler o arquivo.");
                      event.target.value = ''; // Limpa em caso de erro de leitura
                  };
                 reader.readAsText(file);
             }
        });
    } else {
         console.error("Botão #importLocalBtn ou input #importFile não encontrados.");
    }


    // === Fim da Lógica de Importação/Exportação ===


    // === Lógica do Modal de Sucesso ===

    // Função para mostrar o modal de sucesso/notificação
    function showModal(message, title = "Importação Concluída") {
         if (!importSuccessModal) return; // Sai se o modal não existe
        const modalBody = importSuccessModal.querySelector('.modal-body');
         const modalTitle = importSuccessModal.querySelector('.modal-title'); // Pega o título também

         if(modalBody) modalBody.textContent = message;
         if(modalTitle) modalTitle.textContent = title; // Define o título

         // Usa classes para mostrar/esconder via CSS
        importSuccessModal.classList.add('show');
        importSuccessModal.style.display = 'block'; // Garante display se CSS falhar
    }

    // Fechar modal de sucesso no botão 'X' ou 'OK'
    if (closeModalBtn) {
        // O botão OK no HTML já tem um onclick para fechar, mas adicionamos listener no X
        closeModalBtn.addEventListener("click", function() {
            if(importSuccessModal) {
                 importSuccessModal.classList.remove('show');
                 // Adiciona um pequeno delay para a animação CSS antes de esconder completamente
                 setTimeout(() => { importSuccessModal.style.display = 'none'; }, 200); // Ajuste o tempo se necessário
            }
        });
         // Adiciona listener ao botão OK também, se ele não tiver onclick
         const okButton = importSuccessModal.querySelector('.modal-footer button');
         if (okButton && !okButton.hasAttribute('onclick')) {
              okButton.addEventListener("click", function() {
                 if(importSuccessModal) {
                     importSuccessModal.classList.remove('show');
                      setTimeout(() => { importSuccessModal.style.display = 'none'; }, 200);
                 }
             });
         }

    } else {
         console.error("Botão #closeModalBtn não encontrado no modal de sucesso.");
    }

    // === Fim da Lógica do Modal de Sucesso ===


    // --- Carregamento Inicial ---
    console.log("DOM carregado. Carregando textos iniciais...");
    loadTexts();

}); // Fim do DOMContentLoaded
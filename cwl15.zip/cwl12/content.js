// ==UserScript==
// @name         CW Enhanced Text Processor
// @namespace    http://tampermonkey.net/
// @version      2.3 // Placeholders condicionais na substituição de comandos
// @description  Melhora processamento de texto, com substituição instantânea (comandos/placeholders) e remoção de comandos inválidos no Enter. Comandos só são substituídos se placeholders necessários ({nome}) estiverem disponíveis.
// @author       Jocelino S & Gemini/GPT
// @match        *://*/*
// @grant        chrome.storage.local.get
// @grant        chrome.storage.local.set
// @grant        chrome.storage.onChanged.addListener
// @grant        chrome.runtime.sendMessage
// ==/UserScript==
// NOTA: As diretivas @grant acima são para referência se usado como UserScript (Tampermonkey/Greasemonkey).
// Para uma extensão Chrome, as permissões equivalentes devem estar no manifest.json.

(function () {
    "use strict";

    // --- Constants ---
    const API_ENDPOINT_VERIFY_MODE = "https://server-kvy1.onrender.com/verificar-modo";
    const MESSAGE_BOX_ID = "cw-extension-message-box";
    const DATA_IGNORE_ATTRIBUTE = "data-ignore-extension";
    const TYPING_DELAY_MS = 250; // Mantém o delay para input geral, mas a lógica do Enter é instantânea
    const PLACEHOLDER_SAUDACAO = "{saudacao}";
    const PLACEHOLDER_NOME = "{nome}";
    const COMMAND_PREFIX_AT = "@";
    const COMMAND_PREFIX_HASH = "#";
    const MAX_TEXT_LENGTH_PROCESS = 10000;
    const COMMAND_REGEX = new RegExp(`(\\B[${COMMAND_PREFIX_AT}${COMMAND_PREFIX_HASH}][\\w.-]+)\\b`, 'g');
    // Regex para placeholders (usados dentro de substituteText)
    const PLACEHOLDER_SAUDACAO_REGEX = new RegExp(escapeRegex(PLACEHOLDER_SAUDACAO), 'g');
    const PLACEHOLDER_NOME_REGEX = new RegExp(escapeRegex(PLACEHOLDER_NOME), 'g');


    // --- State Variables ---
    let state = {
      userName: null,
      predefinedTexts: {},
      isModoAtivo: true,
      typingTimer: null,
      messageBoxElement: null,
      messageBoxHideTimeout: null,
      lastProcessedElement: null,
      lastProcessedText: null,
    };

    // --- Utility Functions ---

    // Função para escapar caracteres especiais para Regex
    function escapeRegex(string) {
        return string.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    }

    const getMessageBox = () => {
      if (!state.messageBoxElement && document.body) {
        state.messageBoxElement = document.createElement("div");
        state.messageBoxElement.id = MESSAGE_BOX_ID;
        Object.assign(state.messageBoxElement.style, {
          position: 'fixed', top: '20px', left: '50%', transform: 'translateX(-50%)',
          padding: '12px 20px', backgroundColor: '#dc3545', color: 'white',
          fontSize: '15px', fontFamily: 'sans-serif', borderRadius: '6px',
          zIndex: '10001', boxShadow: '0 4px 10px rgba(0, 0, 0, 0.2)',
          opacity: '0', visibility: 'hidden', transition: 'opacity 0.3s ease, visibility 0.3s ease',
          textAlign: 'center', maxWidth: '80%', pointerEvents: 'none'
        });
        document.body.appendChild(state.messageBoxElement);
      } else if (!state.messageBoxElement && !document.body) {
        document.addEventListener('DOMContentLoaded', getMessageBox, { once: true });
      }
      return state.messageBoxElement;
    };

    const showMessage = (message, type = 'error', duration = 3000) => {
      const box = getMessageBox();
      if (!box) return;
      box.textContent = message;
      box.className = 'cw-message-box';
      const colors = { error: '#dc3545', info: '#007bff', 'mode-inactive': '#6c757d' };
      box.style.backgroundColor = colors[type] || colors.error;
      Object.assign(box.style, { opacity: '1', visibility: 'visible'});
      clearTimeout(state.messageBoxHideTimeout);
      if (duration > 0) {
        state.messageBoxHideTimeout = setTimeout(hideMessage, duration);
      } else {
         if (type === 'mode-inactive') box.classList.add('mode-inactive');
      }
    };

    const hideMessage = () => {
      if (state.messageBoxElement) {
        Object.assign(state.messageBoxElement.style, { opacity: '0', visibility: 'hidden'});
        state.messageBoxElement.classList.remove('mode-inactive');
      }
    };

    const checkModeStatus = async () => {
      try {
        const response = await fetch(API_ENDPOINT_VERIFY_MODE, {
          method: 'GET', headers: { 'Accept': 'application/json' }, mode: 'cors', cache: 'no-cache'
        });
        if (!response.ok) throw new Error(`HTTP error! status: ${response.status}`);
        const data = await response.json();
        const prevMode = state.isModoAtivo;
        state.isModoAtivo = data.modoAtivo;
        if (!state.isModoAtivo) {
          showMessage(data.mess || "Extensão desativada.", 'mode-inactive', 0);
        } else if (!prevMode && state.isModoAtivo) {
            if (state.messageBoxElement?.classList.contains('mode-inactive')) hideMessage();
        }
      } catch (error) {
        console.error("CW Ext: Erro ao verificar status:", error);
        state.isModoAtivo = true;
      }
    };

    const updateStateFromStorage = () => {
      if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
        chrome.storage.local.get(["userName", "predefinedTexts"], (data) => {
          state.userName = data.userName || null; // Garante null se não existir ou for vazio
          state.predefinedTexts = data.predefinedTexts || {};
          console.log("CW Ext: Estado carregado:", state);
        });
      } else {
        console.warn("CW Ext: Chrome Storage API não disponível.");
      }
    };

    const getGreeting = () => {
      const hour = new Date().getHours();
      if (hour >= 5 && hour < 12) return "Bom dia";
      if (hour >= 12 && hour < 18) return "Boa tarde";
      return "Boa noite";
    };

    const isElementVisible = (el) => {
        if (!el || !el.isConnected) return false;
        const rect = el.getBoundingClientRect();
        const style = getComputedStyle(el);
        return rect.width > 0 && rect.height > 0 && style.visibility !== 'hidden' && style.display !== 'none' && style.opacity !== '0';
    };

    const isTargetEditable = (target) => {
      if (!target || typeof target.closest !== 'function' || !target.isConnected) return false;
      if (target.closest(`[${DATA_IGNORE_ATTRIBUTE}]`)) return false;
      if (target.closest('input[type="password"]')) return false;
      const element = target;
      if (element.disabled || element.readOnly || !isElementVisible(element)) return false;
      const tagName = element.tagName.toUpperCase();
      if (tagName === 'TEXTAREA' || (tagName === 'INPUT' && ['text', 'search', 'url', 'tel', 'email', 'number', ''].includes(element.type?.toLowerCase() ?? ''))) return true;
      const editableAncestor = element.closest('[contenteditable]');
      if (editableAncestor && editableAncestor.isContentEditable && isElementVisible(editableAncestor)) return true;
      if (element.ownerDocument?.designMode?.toLowerCase() === 'on') return true;
      return false;
    };

    const getTextFromElement = (target) => {
      const editableElement = target.closest('input, textarea, [contenteditable="true"], [contenteditable=""]') || target;
      if (!editableElement) return null;
      if (editableElement.value !== undefined) return editableElement.value;
      if (editableElement.isContentEditable) return editableElement.innerText;
      return null;
    };

    /**
     * **MODIFICADO:** Substitui comandos e placeholders.
     * Comandos (@, #) só são substituídos se placeholders necessários ({nome}) estiverem disponíveis.
     * Placeholders são substituídos *após* a substituição condicional dos comandos.
     * @param {string} text Texto original.
     * @returns {{finalText: string, changed: boolean}} Objeto com texto final e se houve mudança.
     */
    const substituteText = (text) => {
        let changed = false;
        let finalText = text;

        // Otimização inicial
        if (!text || text.length > MAX_TEXT_LENGTH_PROCESS) {
            return { finalText: text, changed: false };
        }
        const hasCommands = text.includes(COMMAND_PREFIX_AT) || text.includes(COMMAND_PREFIX_HASH);
        const hasPlaceholders = text.includes(PLACEHOLDER_SAUDACAO) || (state.userName && text.includes(PLACEHOLDER_NOME)); // Pre-check nome only if userName exists

        if (!hasCommands && !hasPlaceholders) {
             return { finalText: text, changed: false };
        }


        // 1. Substituição CONDICIONAL de Comandos (@, #)
        if (hasCommands) {
            const originalLengthBeforeCmd = finalText.length;
            finalText = finalText.replace(COMMAND_REGEX, (match) => {
                if (state.predefinedTexts.hasOwnProperty(match)) {
                    const resolvedText = state.predefinedTexts[match];
                    const needsNome = resolvedText.includes(PLACEHOLDER_NOME);

                    // Verifica se o placeholder {nome} é necessário mas não está disponível
                    if (needsNome && !state.userName) {
                        // Não substitui o comando, mantém o original
                        console.log(`CW Ext: Comando '${match}' não substituído pois {nome} é necessário mas não está definido.`); // Debug
                        return match;
                    } else {
                        // Substitui o comando pelo seu texto predefinido (placeholders serão tratados depois)
                        return resolvedText;
                    }
                }
                // Se o comando não existe em predefinedTexts, mantém o original
                return match;
            });
            if (finalText.length !== originalLengthBeforeCmd) {
                changed = true; // Indica que houve alguma substituição de comando (mesmo que placeholders ainda não)
            }
        }

        // 2. Substituição GLOBAL de Placeholders (Saudação e Nome)
        //    Isso vai substituir placeholders que vieram dos comandos substituídos
        //    ou placeholders que o usuário digitou manualmente.
        const originalLengthBeforePlaceholder = finalText.length;

        // Substitui {saudacao}
        finalText = finalText.replace(PLACEHOLDER_SAUDACAO_REGEX, getGreeting());

        // Substitui {nome} APENAS se state.userName estiver definido
        if (state.userName) {
            finalText = finalText.replace(PLACEHOLDER_NOME_REGEX, state.userName);
        }

        if (finalText.length !== originalLengthBeforePlaceholder) {
            changed = true; // Indica que houve substituição de placeholder
        }

        // Retorna o texto final e se houve alguma mudança (comando ou placeholder)
        return { finalText, changed };
    };


    const updateTargetValue = (target, newText, originalText) => {
      const editableElement = target.closest('input, textarea, [contenteditable="true"], [contenteditable=""]') || target;
      if (!isTargetEditable(editableElement)) return;

      let selectionStart = null;
      let selectionEnd = null;
      try {
          if (editableElement === document.activeElement) {
              if (editableElement.value !== undefined) {
                  selectionStart = editableElement.selectionStart;
                  selectionEnd = editableElement.selectionEnd;
              } else if (editableElement.isContentEditable) {
                  const selection = window.getSelection();
                  if (selection && selection.rangeCount > 0) {
                      const range = selection.getRangeAt(0);
                      selectionStart = range.startOffset;
                      selectionEnd = range.endOffset;
                  }
              }
          }
      } catch (e) { console.warn("CW Ext: Falha ao obter seleção", e); }

      const textLengthDifference = newText.length - (originalText?.length ?? newText.length);

      if (editableElement.value !== undefined) {
        editableElement.value = newText;
          if (selectionStart !== null) {
            const finalPos = Math.max(0, (selectionEnd ?? selectionStart) + textLengthDifference); // Usa selectionEnd como base se houver seleção
            try {
                setTimeout(() => {
                    editableElement.focus();
                    editableElement.setSelectionRange(finalPos, finalPos);
                }, 0);
            } catch(e) { console.warn("CW Ext: Falha ao definir selectionRange", e); }
          }
      } else if (editableElement.isContentEditable) {
        editableElement.innerText = newText;
          if (selectionStart !== null && document.activeElement === editableElement) {
            setTimeout(() => {
                const sel = window.getSelection();
                if (sel) {
                    const range = document.createRange();
                    let nodeToUse = editableElement.firstChild || editableElement;
                    while (nodeToUse.lastChild && nodeToUse.nodeType === Node.ELEMENT_NODE) { // Prioriza nós de elemento para descer
                        nodeToUse = nodeToUse.lastChild;
                    }
                     // Se o último nó for texto, usa ele, senão o elemento pai
                    const targetNode = nodeToUse.nodeType === Node.TEXT_NODE ? nodeToUse : editableElement;
                    const offset = Math.min(targetNode.textContent?.length ?? 0, selectionEnd + textLengthDifference); // Tenta calcular offset

                    try {
                        editableElement.focus();
                        range.setStart(targetNode, Math.max(0, offset)); // Evita offset negativo
                        range.collapse(true);
                        sel.removeAllRanges();
                        sel.addRange(range);
                    } catch (e) { console.warn("CW Ext: Falha ao definir range em contentEditable", e, targetNode, offset); }
                }
            }, 0);
        }
      }

      // Dispara eventos input/change
      const inputEvent = new Event('input', { bubbles: true, cancelable: true });
      const changeEvent = new Event('change', { bubbles: true, cancelable: false });
      editableElement.dispatchEvent(inputEvent);
      editableElement.dispatchEvent(changeEvent);

      state.lastProcessedElement = editableElement;
      state.lastProcessedText = newText;
    };


    /**
     * Processa o texto do input, geralmente de forma debounced.
     */
    const processTextInput = (target) => {
      if (!state.isModoAtivo || !isTargetEditable(target)) return;

      const currentText = getTextFromElement(target);
      if (currentText === null || currentText.length > MAX_TEXT_LENGTH_PROCESS) return;

      if (target === state.lastProcessedElement && currentText === state.lastProcessedText) {
        return;
      }

      // Usa a função de substituição MODIFICADA
      const { finalText, changed } = substituteText(currentText);

      if (changed) {
        updateTargetValue(target, finalText, currentText);
      } else {
        if (target === state.lastProcessedElement) {
          state.lastProcessedElement = null;
          state.lastProcessedText = null;
        }
      }
    };

    /**
     * Lida com o pressionamento da tecla Enter.
     * MODIFICADO: Usa a nova lógica de substituteText implicitamente ao verificar.
     */
    const handleEnterKey = (event) => {
        if (!state.isModoAtivo) return;
        const target = event.target;
        if (!isTargetEditable(target)) return;

        // Cancela timer pendente do input
        if (state.typingTimer) {
            clearTimeout(state.typingTimer);
            state.typingTimer = null;
        }

        const originalText = getTextFromElement(target);
        if (originalText === null || originalText.length > MAX_TEXT_LENGTH_PROCESS) return;

        // --- Verificação Simplificada ---
        // 1. Tenta substituir tudo (comandos condicionais + placeholders)
        const { finalText: potentialText, changed } = substituteText(originalText);

        // 2. Verifica se ainda existem comandos INVÁLIDOS no texto original
        //    (Comandos que não existem em predefinedTexts ou que precisam de {nome} mas não está disponível)
        let match;
        const invalidCommandsPresent = [];
        COMMAND_REGEX.lastIndex = 0;
        while ((match = COMMAND_REGEX.exec(originalText)) !== null) {
            const command = match[0];
            const definition = state.predefinedTexts[command];
            const needsNome = definition?.includes(PLACEHOLDER_NOME);

            if (!definition) { // Comando não existe
                if (!invalidCommandsPresent.includes(command)) invalidCommandsPresent.push(command);
            } else if (needsNome && !state.userName) { // Comando existe, precisa de nome, mas nome não disponível
                 if (!invalidCommandsPresent.includes(command)) invalidCommandsPresent.push(command);
            }
        }

        // 3. Lógica de Ação
        if (invalidCommandsPresent.length > 0) {
            // Ação: ERRO - Há comandos inválidos ou impossíveis de resolver
            event.preventDefault();
             const messages = [
                (cmds) => `🚨 Ops! ${cmds.join(", ")} ${cmds.length > 1 ? "são inválidos ou precisam de {nome}" : "é inválido ou precisa de {nome}"}!`,
                (cmds) => `❌ Comando${cmds.length > 1 ? "s" : ""} ${cmds.join(", ")} não existe${cmds.length > 1 ? "m" : ""} ou falta o {nome}.`,
                (cmds) => `⚠️ Eita! ${cmds.join(", ")}? Verifique o comando ou se o {nome} está configurado.`,
            ];
            const randomMessage = messages[Math.floor(Math.random() * messages.length)];
            showMessage(randomMessage(invalidCommandsPresent), 'error', 5000); // Aumenta duração da msg

            // Remove APENAS os comandos problemáticos
            let cleanedText = originalText;
            invalidCommandsPresent.forEach(invalidCmd => {
                cleanedText = cleanedText.replaceAll(invalidCmd, '');
            });
            cleanedText = cleanedText.replace(/\s{2,}/g, ' ').trim();
            updateTargetValue(target, cleanedText, originalText); // Atualiza o campo com o texto limpo

            state.lastProcessedElement = null;
            state.lastProcessedText = null;
            console.log("CW Ext: Comandos inválidos/não resolvidos removidos no Enter:", invalidCommandsPresent);
            return;

        } else if (changed && potentialText !== originalText) {
             // Ação: SUCESSO - Houve substituição válida (comando e/ou placeholder)
             event.preventDefault();
             updateTargetValue(target, potentialText, originalText); // Usa o texto já processado por substituteText
             console.log("CW Ext: Substituições realizadas no Enter.");
             return;

        } else {
            // Ação: NADA A FAZER - Nenhuma substituição ocorreu ou foi necessária, Enter permitido.
            state.lastProcessedElement = null;
            state.lastProcessedText = null;
            // console.log("CW Ext: Enter permitido - sem substituições válidas ou comandos inválidos."); // Debug
        }
    };


    // --- Event Listeners Setup ---
    const setupEventListeners = () => {
      document.addEventListener("input", onInput, { capture: true, passive: true });
      document.addEventListener("keydown", onKeyDown, { capture: true });
      window.addEventListener("message", onWindowMessage, { passive: true });
      if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.onChanged) {
        chrome.storage.onChanged.addListener(onStorageChanged);
      }
    };

    // Debounced input handler
    const onInput = (event) => {
      clearTimeout(state.typingTimer);
      state.typingTimer = null;
      if (!isTargetEditable(event.target)) return;
      const targetElement = event.target;
      state.typingTimer = setTimeout(() => {
        state.typingTimer = null;
        processTextInput(targetElement);
      }, TYPING_DELAY_MS);
    };

    const onKeyDown = (event) => {
      if (event.key === 'Enter' && !event.shiftKey && !event.ctrlKey && !event.altKey && !event.metaKey) {
        handleEnterKey(event);
      }
    };

    const onStorageChanged = (changes, areaName) => {
      if (areaName === "local") {
        let stateChanged = false;
        if (changes.hasOwnProperty('userName')) { // Verifica se a chave existe na mudança
          state.userName = changes.userName.newValue || null;
          stateChanged = true;
        }
        if (changes.hasOwnProperty('predefinedTexts')) {
          state.predefinedTexts = changes.predefinedTexts.newValue || {};
          stateChanged = true;
        }
        if(stateChanged) {
            console.log("CW Ext: Estado atualizado via storage.onChanged:", state);
        }
      }
    };

    const onWindowMessage = (event) => {
        if (event.source !== window || !event.data) return;
        if (event.data.from === "login-page" && event.data.action === "redirectCallback" && event.data.token) {
           if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.sendMessage) {
             chrome.runtime.sendMessage({ action: "processTokenFromCallback", token: event.data.token });
           }
        }
    };

    // --- Initialization ---
    const initialize = () => {
        console.log("CW Ext: Inicializando script de conteúdo v2.3...");
        getMessageBox();
        updateStateFromStorage();
        setupEventListeners();
        checkModeStatus();
        setInterval(checkModeStatus, 5 * 60 * 1000);
    };

    // --- Run ---
    if (!window.cwExtensionInitialized) {
      window.cwExtensionInitialized = true;
      if (document.readyState === 'loading') {
          document.addEventListener('DOMContentLoaded', initialize, { once: true });
      } else {
          initialize();
      }
    } else {
        console.log("CW Ext: Tentativa de reinicialização evitada.");
    }

})();


















/**
 * Content Script para a Extensão CW: Fornece ícones flutuantes,
 * um menu lateral de busca de comandos e um menu lateral de bloco de notas.
 */
(function () {
  "use strict"; // Habilita o modo estrito

  // --- Constantes ---
  const SIDE_MENU_ID = 'cwSideMenu';
  const NOTES_MENU_ID = 'cwNotesMenu';
  const NOTES_TEXTAREA_ID = 'cwNotesTextarea';
  const SEARCH_INPUT_ID = 'cwSearchInput';
  const TEXT_LIST_ID = 'cwTextList';
  const FLOATING_CONTAINER_CLASS = 'cw-floating-container';
  const DEBOUNCE_DELAY = 500; // ms para salvar notas
  const ANIMATION_DURATION = 300; // ms para transições do menu (deve corresponder ao CSS)

  // --- Variáveis de Escopo do Módulo ---
  let floatingIconContainer = null; // Referência para a div container dos ícones
  let icons = {};                   // Armazena referências aos elementos dos ícones individuais
  let sideMenuElement = null;       // Referência para a div do menu lateral de busca de comandos
  let notesMenuElement = null;      // Referência para a div do menu lateral de notas
  let notesTextarea = null;         // Referência para o elemento textarea das notas
  let searchInput = null;           // Referência para o elemento input de busca
  let textListDiv = null;           // Referência para a div da lista de comandos

  // Dados em cache para eficiência da busca
  let cachedPredefinedTexts = {};
  let cachedUserName = "";
  let saveNotesTimeout = null;      // ID do Timeout para debouncing do salvamento de notas

  // --- Funções Utilitárias ---

  /**
   * Cria um elemento HTML com tag, atributos, classes e conteúdo de texto especificados.
   * @param {string} tag - O nome da tag HTML (ex: 'div', 'button').
   * @param {object} [attributes={}] - Pares chave-valor de atributos (ex: { id: 'myId', 'data-custom': 'value' }).
   * @param {string[]} [classes=[]] - Um array de nomes de classes CSS.
   * @param {string} [textContent=''] - O conteúdo de texto interno do elemento.
   * @returns {HTMLElement} O elemento HTML recém-criado.
   */
  function createElement(tag, attributes = {}, classes = [], textContent = '') {
      const element = document.createElement(tag);
      for (const key in attributes) {
          element.setAttribute(key, attributes[key]);
      }
      classes.forEach(cls => element.classList.add(cls));
      if (textContent) {
          element.textContent = textContent;
      }
      return element;
  }

  /**
   * Obtém uma saudação baseada na hora atual do dia.
   * @returns {string} Saudação ("Bom dia", "Boa tarde", "Boa noite").
   */
  function getSaudacao() {
      const hour = new Date().getHours();
      if (hour >= 5 && hour < 12) return "Bom dia";
      if (hour >= 12 && hour < 18) return "Boa tarde";
      return "Boa noite";
  }

  /**
   * Atualiza o valor da textarea de notas se ela existir e o valor for diferente.
   * Previne manipulação desnecessária do DOM se o menu estiver fechado ou o valor for o mesmo.
   * @param {string} newNotesValue - O novo valor recuperado do storage.
   */
  function updateNotesTextarea(newNotesValue) {
      // Garante que o menu de notas e a textarea estão atualmente no DOM
      const currentTextarea = document.getElementById(NOTES_TEXTAREA_ID);
      if (currentTextarea && currentTextarea.value !== newNotesValue) {
          currentTextarea.value = newNotesValue;
          console.log("Textarea de notas atualizada pela mudança no storage.");
      }
  }

  /**
   * Salva o conteúdo atual da textarea de notas no chrome.storage.local.
   * Usa debouncing para evitar escritas excessivas durante a digitação.
   */
  function saveNotes() {
      clearTimeout(saveNotesTimeout);
      saveNotesTimeout = setTimeout(() => {
          // Garante que a textarea ainda existe antes de tentar salvar
          if (notesTextarea) {
              chrome.storage.local.set({ notes: notesTextarea.value }, () => {
                  if (chrome.runtime.lastError) {
                      console.error("Erro ao salvar notas:", chrome.runtime.lastError);
                  } else {
                      // Opcional: adicionar um indicador sutil de salvamento?
                  }
              });
          }
      }, DEBOUNCE_DELAY);
  }

  // --- Funções de Criação da UI ---

  /**
   * Cria um único elemento de ícone flutuante.
   * @param {string} id - Identificador único para o ID do elemento do ícone (usado também no 'title').
   * @param {string} text - Conteúdo de texto ou emoji para o ícone.
   * @param {function} clickHandler - Função a ser executada quando o ícone é clicado.
   * @param {boolean} [isText=false] - Se verdadeiro, adiciona uma classe específica para ícones baseados em texto (como 'CW').
   * @returns {HTMLElement} O elemento do ícone criado.
   */
  function createFloatingIcon(id, text, clickHandler, isText = false) {
      const iconClasses = ['cw-floating-icon'];
      if (isText) {
          iconClasses.push('icon-text');
      }
      // Usa o 'id' como 'title' para tooltip
      const icon = createElement('div', { id: `cw-icon-${id.replace(/\s+/g, '-')}`, title: id }, iconClasses, text);
      icon.addEventListener('click', (event) => {
          event.stopPropagation(); // Previne que cliques se propaguem, se necessário
          clickHandler();
      });
      return icon;
  }

  /**
   * Cria e anexa o container dos ícones flutuantes e os ícones ao body da página.
   * Evita duplicação se a função for chamada múltiplas times.
   */
  function setupFloatingIcons() {
      // Previne a criação de múltiplos containers
      if (document.querySelector(`.${FLOATING_CONTAINER_CLASS}`)) return;

      floatingIconContainer = createElement('div', {}, [FLOATING_CONTAINER_CLASS]);

      // Ícone Principal (CW) -> Abre Busca de Comandos
      icons.main = createFloatingIcon('Buscar Comandos', 'CW', () => {
          openSideMenu();
          hideFloatingIcons();
      }, true); // true indica conteúdo de texto

      // Ícone de Notas (📝) -> Abre Notas
      icons.notes = createFloatingIcon('Bloco de Notas', '📝', () => {
          openNotesMenu();
          hideFloatingIcons();
      });

      // Exemplo: Ícone de Configurações (⚙️) - Descomente se necessário
      // icons.config = createFloatingIcon('Configurações', '⚙️', () => {
      //   chrome.runtime.sendMessage({ action: "openOptionsPage" });
      //   // Considere esconder os ícones aqui também se a página de opções não sobrepuser
      // });

      // Anexa os ícones ao container
      floatingIconContainer.appendChild(icons.main);
      floatingIconContainer.appendChild(icons.notes);
      // floatingIconContainer.appendChild(icons.config); // Descomente se usar

      document.body.appendChild(floatingIconContainer);
      console.log("Ícones flutuantes criados.");
  }

  /**
   * Cria um elemento de cabeçalho padrão para os menus laterais.
   * @param {string} titleText - O título exibido no cabeçalho.
   * @param {function} closeHandler - Função a ser chamada quando o botão de fechar é clicado.
   * @returns {HTMLElement} O elemento de cabeçalho criado.
   */
  function createMenuHeader(titleText, closeHandler) {
      const header = createElement('div', {}, ['cw-menu-header']);
      const title = createElement('span', {}, ['cw-menu-title'], titleText);
      // Usando '✕' (sinal de multiplicação) como símbolo comum de fechar
      const closeButton = createElement('button', { 'aria-label': 'Fechar', title: 'Fechar' }, ['cw-menu-close-button'], '✕');
      closeButton.addEventListener('click', closeHandler);

      header.appendChild(title);
      header.appendChild(closeButton);
      return header;
  }

  /**
   * Abre o menu lateral para buscar comandos. Busca os dados dos comandos uma vez ao abrir.
   */
  function openSideMenu() {
      // Previne abrir múltiplos menus de busca
      if (document.getElementById(SIDE_MENU_ID)) return;

      // Fecha menu de notas se estiver aberto
      if (notesMenuElement) closeNotesMenu(false); // Não restaura ícones ainda

      sideMenuElement = createElement('div', { id: SIDE_MENU_ID }, ['cw-side-menu']);

      const closeMenu = () => closeSideMenu(); // Usa a função de fechar dedicada

      const header = createMenuHeader('Buscar Comandos', closeMenu);

      const contentDiv = createElement('div', {}, ['cw-menu-content']);
      searchInput = createElement('input', {
          type: 'text',
          id: SEARCH_INPUT_ID,
          placeholder: 'Digite para buscar comandos...',
          'data-ignore-extension': 'true' // Mantém atributo customizado se necessário
      }, ['cw-search-input']);
      textListDiv = createElement('div', { id: TEXT_LIST_ID }, ['cw-text-list']);

      searchInput.addEventListener('input', handleSearchInput);

      contentDiv.appendChild(searchInput);
      contentDiv.appendChild(textListDiv);

      sideMenuElement.appendChild(header);
      sideMenuElement.appendChild(contentDiv);

      document.body.appendChild(sideMenuElement);

      // Busca dados *após* criar a estrutura do menu
      chrome.storage.local.get(["predefinedTexts", "userName"], (data) => {
          if (chrome.runtime.lastError) {
              console.error("Erro ao buscar dados iniciais dos comandos:", chrome.runtime.lastError);
              cachedPredefinedTexts = {}; // Define como vazio em caso de erro
              cachedUserName = "";
          } else {
              cachedPredefinedTexts = data.predefinedTexts || {};
              cachedUserName = data.userName || "";
          }
          // Garante que o menu não foi fechado imediatamente após abrir, antes de renderizar
          if (sideMenuElement && textListDiv) {
              renderCommandList(cachedPredefinedTexts, cachedUserName, ""); // Renderização inicial (todos os comandos)
          }
      });

      // Dispara animação e foco *após* anexar e carregar dados potenciais
      requestAnimationFrame(() => {
           if (!sideMenuElement) return; // Verifica se foi fechado rapidamente
           // Força reflow antes de adicionar classe - truque padrão
           void sideMenuElement.offsetWidth;
           sideMenuElement.classList.add('is-open');
           if(searchInput) {
               searchInput.focus();
           }
           console.log("Menu de busca de comandos aberto.");
      });
  }


  /**
   * Abre o menu lateral para notas. Carrega notas salvas ao abrir.
   */
  function openNotesMenu() {
      // Previne abrir múltiplos menus de notas
      if (document.getElementById(NOTES_MENU_ID)) return;

      // Fecha menu de busca se estiver aberto
      if (sideMenuElement) closeSideMenu(false); // Não restaura ícones ainda

      notesMenuElement = createElement('div', { id: NOTES_MENU_ID }, ['cw-side-menu']); // Reusa classe base

      const closeMenu = () => closeNotesMenu(); // Usa a função de fechar dedicada

      const header = createMenuHeader('Bloco de Notas', closeMenu);

      const contentDiv = createElement('div', {}, ['cw-menu-content']); // Reusa classe
      notesTextarea = createElement('textarea', {
          id: NOTES_TEXTAREA_ID,
          placeholder: 'Digite suas notas aqui...', // Adicionado placeholder
          'data-ignore-extension': 'true'
      }, ['cw-notes-textarea']);

      notesTextarea.addEventListener('input', saveNotes); // Usa função de salvar com debounce

      contentDiv.appendChild(notesTextarea);

      notesMenuElement.appendChild(header);
      notesMenuElement.appendChild(contentDiv);

      document.body.appendChild(notesMenuElement);

      // Carrega notas salvas *após* criar a estrutura do menu
      chrome.storage.local.get('notes', (data) => {
           if (chrome.runtime.lastError) {
               console.error("Erro ao carregar notas:", chrome.runtime.lastError);
           } else if (notesTextarea) { // Verifica se menu não foi fechado imediatamente
               notesTextarea.value = data.notes || ""; // Usa string vazia se não houver notas salvas
           }
      });


      // Dispara animação e foco *após* anexar e carregar dados potenciais
      requestAnimationFrame(() => {
           if (!notesMenuElement) return; // Verifica se foi fechado rapidamente
           // Força reflow antes de adicionar classe
           void notesMenuElement.offsetWidth;
           notesMenuElement.classList.add('is-open');
            if (notesTextarea) {
                notesTextarea.focus();
            }
           console.log("Menu de notas aberto.");
      });
  }

  // --- Funções de Fechamento de Menu ---

  /**
   * Fecha o menu lateral de busca de comandos com animação.
   * @param {boolean} [restoreIcons=true] - Se deve restaurar a visibilidade dos ícones flutuantes.
   */
  function closeSideMenu(restoreIcons = true) {
      if (!sideMenuElement) return;

      sideMenuElement.classList.remove('is-open');

      // Espera a animação antes de remover o elemento e limpar
      setTimeout(() => {
          if (sideMenuElement) {
              sideMenuElement.remove();
          }
          // Limpa referências
          sideMenuElement = null;
          searchInput = null;
          textListDiv = null;
          cachedPredefinedTexts = {}; // Limpa cache
          cachedUserName = "";

          if (restoreIcons) {
              restoreFloatingIcons();
          }
          console.log("Menu de busca de comandos fechado.");
      }, ANIMATION_DURATION);
  }

  /**
   * Fecha o menu lateral de notas com animação.
   * @param {boolean} [restoreIcons=true] - Se deve restaurar a visibilidade dos ícones flutuantes.
   */
  function closeNotesMenu(restoreIcons = true) {
      if (!notesMenuElement) return;

      notesMenuElement.classList.remove('is-open');

      // Garante que as últimas notas sejam salvas imediatamente ao fechar, ignorando o debounce
      clearTimeout(saveNotesTimeout);
      if (notesTextarea && notesTextarea.value !== undefined) { // Verifica se textarea existe e tem um valor
          chrome.storage.local.set({ notes: notesTextarea.value }, () => {
              if (chrome.runtime.lastError) {
                  console.error("Erro ao salvar notas ao fechar:", chrome.runtime.lastError);
              }
          });
      }


      // Espera a animação antes de remover o elemento e limpar
      setTimeout(() => {
          if (notesMenuElement) {
              notesMenuElement.remove();
          }
          // Limpa referências
          notesMenuElement = null;
          notesTextarea = null; // Importante!

          if (restoreIcons) {
              restoreFloatingIcons();
          }
          console.log("Menu de notas fechado.");
      }, ANIMATION_DURATION);
  }


  // --- Gerenciamento de Visibilidade dos Ícones ---

  /** Esconde o container dos ícones flutuantes. */
  function hideFloatingIcons() {
      if (floatingIconContainer) {
          floatingIconContainer.style.display = 'none';
      }
  }

  /** Restaura a visibilidade do container dos ícones flutuantes (usando flex). */
  function restoreFloatingIcons() {
      if (floatingIconContainer) {
          floatingIconContainer.style.display = 'flex';
      }
  }

  // --- Lógica de Busca e Renderização ---

  /**
   * Renderiza a lista filtrada de comandos com base na query de busca.
   * Usa dados em cache para eficiência.
   * @param {object} texts - O objeto completo de comandos { comando: texto }.
   * @param {string} userName - O nome do usuário para substituição.
   * @param {string} searchQuery - O termo de busca atual (minúsculo, sem espaços extras).
   */
  function renderCommandList(texts, userName, searchQuery) {
      if (!textListDiv) return; // Sai se o container da lista não existir (menu fechado)

      textListDiv.innerHTML = ''; // Limpa resultados anteriores

      let results = {};
      const searchWords = searchQuery.split(/\s+/).filter(Boolean); // Obtém palavras individuais da busca

      // --- Lógica de Filtragem e Pontuação ---
      for (const command in texts) {
          let text = texts[command]; // Texto original para processamento
          const commandLower = command.toLowerCase();
          const textLower = text.toLowerCase();
          // Combina comando e texto para correspondência mais ampla
          const fullContentLower = `${commandLower} ${textLower}`;

          let score = 0;
          let matchesQuery = !searchQuery; // Assume correspondência se a busca estiver vazia

          if (searchQuery) {
              matchesQuery = false; // Reseta para busca real

              // 1. Correspondência de frase exata (maior relevância) - verifica dentro do conteúdo combinado
              if (fullContentLower.includes(searchQuery)) {
                  score += 10;
                  matchesQuery = true;
              }

              // 2. Todas as palavras da busca presentes (alta relevância)
              const allWordsMatch = searchWords.every(word => fullContentLower.includes(word));
              if (allWordsMatch) {
                  score += 5; // Adiciona à pontuação, pode já ter pontos da correspondência de frase
                  matchesQuery = true;
              }

              // 3. Correspondência parcial (pelo menos uma palavra) (baixa relevância)
              // Verifica se já não correspondeu por allWords para evitar contagem dupla em casos simples
              if (!allWordsMatch) {
                   const partialMatch = searchWords.some(word => fullContentLower.includes(word));
                   if (partialMatch) {
                       score += 2;
                       matchesQuery = true;
                   }
              }


              // 4. Bônus se o *nome* do comando começa com a primeira palavra da busca
              if (searchWords.length > 0 && commandLower.startsWith(searchWords[0])) {
                  score += 3;
                  matchesQuery = true;
              }
          } else {
               // Pontuação base para exibir todos os itens quando a busca está vazia
               score = 1;
          }


          // Se corresponde à query (ou query está vazia) e tem pontuação positiva
          if (matchesQuery && score > 0) {
              // Realiza substituições dinâmicas ({saudacao}, {nome})
              if (text.includes("{saudacao}")) {
                  text = text.replace(/{saudacao}/g, getSaudacao());
              }
              if (text.includes("{nome}") && userName) {
                  text = text.replace(/{nome}/g, userName);
              }
              results[command] = { text: text, score: score };
          }
      }
      // --- Fim da Filtragem ---


      // Ordena comandos por pontuação (decrescente), depois alfabeticamente para empates
      const sortedCommands = Object.keys(results).sort((a, b) => {
          const scoreDiff = results[b].score - results[a].score;
          if (scoreDiff !== 0) {
              return scoreDiff;
          }
          return a.localeCompare(b); // Ordenação alfabética para mesma pontuação
      });

      // --- Cria e Anexa Cards de Resultado ---
      if (sortedCommands.length > 0) {
           sortedCommands.forEach(command => {
               const card = createElement('div', {}, ['cw-command-card']);
               const title = createElement('h5', {}, ['cw-card-title'], command);
               // Usa CSS white-space: pre-wrap para preservação da formatação
               const body = createElement('p', {}, ['cw-card-text'], results[command].text);

               card.appendChild(title);
               card.appendChild(body);

               // Handler para copiar texto ao clicar no card
               const copyHandler = (event) => {
                   event.stopPropagation(); // Previne propagação do evento, se necessário
                   navigator.clipboard.writeText(results[command].text)
                       .then(() => {
                           // Feedback visual: adiciona classe 'copied' (borda) e bg temporário
                           card.classList.add('copied');
                           card.classList.add('copy-success-temp'); // Classe para BG temporário

                           setTimeout(() => {
                               card.classList.remove('copied');
                               card.classList.remove('copy-success-temp');
                           }, 1500); // Reverte após 1.5 segundos
                       })
                       .catch(err => {
                           console.error('Falha ao copiar texto:', err);
                           // Feedback visual de erro
                           card.classList.add('copy-error-temp'); // Classe para BG de erro temporário
                            setTimeout(() => {
                                card.classList.remove('copy-error-temp');
                            }, 2000);
                       });
               };

               // Adiciona o listener de clique diretamente ao card
               card.addEventListener('click', copyHandler);
               card.setAttribute('title', 'Clique para copiar'); // Tooltip para o card

               textListDiv.appendChild(card);
           });
      } else if (searchQuery) {
          // Mensagem se a busca não retornar resultados
          textListDiv.innerHTML = '<p class="cw-no-results">Nenhum comando encontrado para sua busca.</p>';
      } else {
           // Mensagem se não houver comandos definidos
           textListDiv.innerHTML = '<p class="cw-no-results">Nenhum comando foi definido ainda.</p>';
      }

  }

  /** Manipula eventos de input no campo de busca, filtrando a lista de comandos em cache. */
  function handleSearchInput() {
      if (!searchInput) return;
      const searchTerm = searchInput.value.toLowerCase().trim();
      // Renderiza usando os dados *em cache*
      renderCommandList(cachedPredefinedTexts, cachedUserName, searchTerm);
  }

  // --- Configuração de Event Listeners ---

  /** Configura o listener para mudanças no chrome.storage.local. */
  function setupStorageListener() {
      chrome.storage.onChanged.addListener((changes, areaName) => {
          if (areaName !== 'local') return;

          // Manipula mudanças nas notas
          if (changes.notes) {
              console.log("Detectada mudança no storage 'notes'.");
              // Atualiza textarea APENAS se o menu de notas estiver aberto
              if (notesMenuElement && notesTextarea) {
                  updateNotesTextarea(changes.notes.newValue);
              }
          }

          // Manipula mudanças nos textos predefinidos ou nome de usuário
          let needsReRender = false;
          if (changes.predefinedTexts) {
               console.log("Detectada mudança no storage 'predefinedTexts'.");
               cachedPredefinedTexts = changes.predefinedTexts.newValue || {};
               needsReRender = true;
          }
          if (changes.userName) {
               console.log("Detectada mudança no storage 'userName'.");
               cachedUserName = changes.userName.newValue || "";
               needsReRender = true;
          }

          // Re-renderiza lista de comandos APENAS se o menu de busca estiver aberto e os dados mudaram
          if (needsReRender && sideMenuElement && searchInput && textListDiv) {
               console.log("Re-renderizando lista de comandos devido à mudança no storage.");
               const currentSearchTerm = searchInput.value.toLowerCase().trim();
               renderCommandList(cachedPredefinedTexts, cachedUserName, currentSearchTerm);
          }
      });
  }

  /** Injeta estilos CSS no head da página. */
  function injectStyles() {
       const styleId = 'cw-dynamic-styles';
       if (document.getElementById(styleId)) return; // Evita estilos duplicados

       const styleElement = document.createElement('style');
       styleElement.id = styleId;
       styleElement.textContent = `
          /* Estilos da Extensão CW */
          :root {
                --cw-primary-color: #005eff; /* Azul primário ajustado */
                --cw-secondary-color: #6c757d; /* Cinza secundário padrão */
                --cw-success-color: #28a745;
                --cw-success-bg-temp: #d4edda; /* Verde claro para feedback */
                --cw-danger-color: #dc3545;
                --cw-danger-bg-temp: #f8d7da; /* Vermelho claro para feedback de erro */
                --cw-icon-bg: linear-gradient(135deg, #005eff, #20c997, #ffc107); /* Gradiente refinado */
                --cw-icon-color: white;
                /* --- ALTERAÇÕES AQUI --- */
                --cw-icon-size: 30px; /* << REDUZIDO o tamanho do ícone */
                --cw-icon-font-size: 15px; /* << REDUZIDO tamanho da fonte (emoji) */
                --cw-icon-text-font-size: 11px; /* << REDUZIDO tamanho da fonte (texto 'CW') */
                --cw-icon-spacing: 8px; /* << REDUZIDO espaçamento entre ícones */
                /* --- FIM DAS ALTERAÇÕES --- */
                --cw-icon-shadow: 0 3px 6px rgba(0, 0, 0, 0.2); /* Sombra um pouco menor */
                --cw-icon-shadow-hover: 0 5px 10px rgba(0, 0, 0, 0.3); /* Sombra hover menor */
                --cw-menu-bg: rgba(255, 255, 255, 0.98); /* Quase opaco */
                --cw-menu-width: 360px;
                --cw-menu-shadow: -2px 0 15px rgba(0, 0, 0, 0.2); /* Sombra à esquerda */
                --cw-header-bg: var(--cw-primary-color);
                --cw-header-color: white;
                --cw-header-height: 50px;
                --cw-border-color: #dee2e6; /* Borda mais clara */
                --cw-card-bg: #ffffff;
                --cw-card-border: var(--cw-border-color);
                --cw-card-hover-bg: #f8f9fa; /* Hover sutil */
                --cw-input-focus-border: var(--cw-primary-color);
                --cw-input-focus-shadow: 0 0 0 3px rgba(0, 94, 255, 0.25);
                --cw-animation-duration: ${ANIMATION_DURATION}ms; /* Usa constante JS */
            }

            /* Container dos Ícones Flutuantes */
            .${FLOATING_CONTAINER_CLASS} {
                position: fixed;
                top: 50%;
                /* --- ALTERAÇÃO AQUI --- */
                right: 5px; /* << REDUZIDO para ficar mais perto da borda */
                /* --- FIM DA ALTERAÇÃO --- */
                transform: translateY(-50%);
                display: flex;
                flex-direction: column;
                align-items: center;
                gap: var(--cw-icon-spacing); /* Usa a variável atualizada */
                z-index: 9999;
                transition: right 0.3s ease; /* Esconder/mostrar suave se necessário */
            }

            /* Ícone Flutuante Individual */
            .cw-floating-icon {
                width: var(--cw-icon-size); /* Usa a variável atualizada */
                height: var(--cw-icon-size); /* Usa a variável atualizada */
                background: var(--cw-icon-bg);
                color: var(--cw-icon-color);
                border-radius: 50%;
                cursor: pointer;
                display: flex;
                align-items: center;
                justify-content: center;
                box-shadow: var(--cw-icon-shadow); /* Usa a variável atualizada */
                transition: transform 0.2s ease, box-shadow 0.2s ease, opacity 0.3s ease;
                opacity: 0.6;
                font-family: Arial, sans-serif;
                font-weight: bold;
                font-size: var(--cw-icon-font-size); /* Usa a variável atualizada */
                line-height: 1;
                user-select: none;
            }

            .cw-floating-icon:hover {
                transform: scale(1.15); /* Mantém o efeito de pop */
                box-shadow: var(--cw-icon-shadow-hover); /* Usa a variável atualizada */
                opacity: 1;
            }

            /* Estilo específico para ícone de texto ('CW') */
            .cw-floating-icon.icon-text {
                font-size: var(--cw-icon-text-font-size); /* Usa a variável atualizada */
            }

          /* Estilo Base do Menu Lateral */
          .cw-side-menu {
              position: fixed;
              top: 0;
              right: calc(-1 * var(--cw-menu-width)); /* Começa fora da tela */
              width: var(--cw-menu-width);
              height: 100vh; /* Altura total da viewport */
              background-color: var(--cw-menu-bg);
              backdrop-filter: blur(5px); /* Opcional: desfocar fundo */
              box-shadow: var(--cw-menu-shadow);
              z-index: 9998;
              display: flex;
              flex-direction: column;
              overflow: hidden; /* Previne vazamento de conteúdo durante animação */
              transition: right var(--cw-animation-duration) ease-in-out;
              box-sizing: border-box;
          }

          .cw-side-menu.is-open {
              right: 0; /* Desliza para dentro */
          }

          /* Cabeçalho do Menu */
          .cw-menu-header {
              flex-shrink: 0; /* Previne encolhimento */
              height: var(--cw-header-height);
              background-color: var(--cw-header-bg);
              color: var(--cw-header-color);
              display: flex;
              align-items: center;
              justify-content: space-between;
              padding: 0 15px;
              box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
          }

          .cw-menu-title {
              font-size: 18px; /* Título ligeiramente maior */
              font-weight: 600; /* Semi-negrito */
              white-space: nowrap;
              overflow: hidden;
              text-overflow: ellipsis;
          }

          .cw-menu-close-button {
              font-size: 24px; /* Botão de fechar maior */
              background: none;
              border: none;
              color: var(--cw-header-color);
              cursor: pointer;
              padding: 5px; /* Adiciona padding para clique mais fácil */
              margin-left: 10px;
              line-height: 1;
              opacity: 0.8;
               transition: opacity 0.2s ease;
          }
          .cw-menu-close-button:hover {
              opacity: 1;
          }

          /* Área de Conteúdo do Menu */
          .cw-menu-content {
              flex-grow: 1; /* Ocupa altura restante */
              padding: 15px;
              overflow-y: auto; /* Habilita scroll para conteúdo */
              display: flex;
              flex-direction: column; /* Importante para crescimento da textarea */
          }

          /* Input de Busca */
          .cw-search-input {
              width: 100%;
              padding: 12px 15px; /* Mais padding */
              font-size: 15px;
              border-radius: 6px;
              border: 1px solid var(--cw-border-color);
              box-sizing: border-box;
              margin-bottom: 15px;
               transition: border-color 0.2s ease, box-shadow 0.2s ease;
          }

          .cw-search-input:focus {
              border-color: var(--cw-input-focus-border);
              outline: none;
              box-shadow: var(--cw-input-focus-shadow);
          }

          /* Container da Lista de Comandos */
          .cw-text-list {
              /* Nenhum estilo específico necessário aqui agora, os cards cuidam da estrutura */
          }

           /* Mensagem de Nenhum Resultado */
           .cw-no-results {
               color: var(--cw-secondary-color);
               text-align: center;
               padding: 20px;
               font-style: italic;
           }


          /* Card de Comando */
          .cw-command-card {
              border: 1px solid var(--cw-card-border);
              border-radius: 6px;
              margin-bottom: 12px;
              padding: 15px;
              background-color: var(--cw-card-bg);
              cursor: pointer; /* Indica que o card é clicável */
              transition: background-color 0.2s ease, box-shadow 0.2s ease, border-left 0.2s ease;
              position: relative;
               box-shadow: 0 1px 3px rgba(0,0,0,0.05);
               border-left: 4px solid transparent; /* Espaço para borda de feedback */
          }
          .cw-command-card:hover {
              background-color: var(--cw-card-hover-bg);
               box-shadow: 0 2px 5px rgba(0,0,0,0.1);
          }
           /* Feedback de cópia bem-sucedida (borda) */
           .cw-command-card.copied {
               border-left-color: var(--cw-success-color);
           }
          /* Feedback de cópia bem-sucedida (BG temporário) */
          .cw-command-card.copy-success-temp {
              background-color: var(--cw-success-bg-temp);
              transition: background-color 0.1s ease-in-out; /* Transição rápida para o BG */
          }
           /* Feedback de erro de cópia (BG temporário) */
          .cw-command-card.copy-error-temp {
              background-color: var(--cw-danger-bg-temp);
               border-left-color: var(--cw-danger-color);
               transition: background-color 0.1s ease-in-out, border-left-color 0.1s ease-in-out;
          }


          .cw-card-title {
              font-size: 16px;
              font-weight: 600;
              margin: 0 0 8px 0; /* Mais espaço abaixo do título */
               color: #333;
               pointer-events: none; /* Título e texto não interferem no clique do card */
          }

          .cw-card-text {
              font-size: 14px;
              margin: 0; /* Removida margem inferior extra */
              white-space: pre-wrap; /* Preserva quebras de linha e espaços */
              word-wrap: break-word; /* Previne overflow */
              color: #555;
               line-height: 1.5;
               pointer-events: none; /* Título e texto não interferem no clique do card */
          }

          /* Removidos estilos .cw-copy-button */

          /* Textarea de Notas */
          .cw-notes-textarea {
              width: 100%;
              flex-grow: 1; /* Ocupa espaço vertical disponível */
              padding: 12px 15px;
              font-size: 14px;
              line-height: 1.6; /* Melhor legibilidade para notas */
              border-radius: 6px;
              border: 1px solid var(--cw-border-color);
              box-sizing: border-box;
              resize: none; /* Desabilita redimensionamento manual */
               transition: border-color 0.2s ease, box-shadow 0.2s ease;
               font-family: inherit; /* Usa fonte da página */
          }
          .cw-notes-textarea:focus {
              border-color: var(--cw-input-focus-border);
              outline: none;
              box-shadow: var(--cw-input-focus-shadow);
          }

          /* Atributo para elementos ignorarem por outras extensões potenciais */
          [data-ignore-extension="true"] {
              /* Nenhum estilo visual necessário, apenas um marcador */
          }
       `;
       document.head.appendChild(styleElement);
  }

  // --- Inicialização ---

  /** Função principal de inicialização. */
  function initialize() {
      console.log("Inicializando Content Script da Extensão CW...");
      // Injeta estilos CSS primeiro
      injectStyles();

      // Cria ícones flutuantes
      setupFloatingIcons();

      // Configura listener para mudanças no storage (notas, comandos)
      setupStorageListener();

      console.log("Extensão CW Inicializada.");
  }

  // --- Ponto de Entrada ---
  // Garante que o DOM está pronto antes de manipulá-lo.
  if (document.readyState === "loading") {
      document.addEventListener("DOMContentLoaded", initialize);
  } else {
      initialize(); // DOM já está pronto
  }

})(); // Fim do IIFE
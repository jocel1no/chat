document.addEventListener('DOMContentLoaded', () => {
    let currentSymbol = '@'; // Variável global para armazenar o símbolo atual
    
    const toggleSymbolBtn = document.getElementById('toggleSymbolBtn');
    const symbolDisplay = document.getElementById('symbolDisplay');
    const nameModal = document.getElementById('nameModal');
    const userNameInput = document.getElementById('userNameInput');
    const saveNameBtn = document.getElementById('saveNameBtn');
    const userNameDisplay = document.getElementById('userNameDisplay');
    const userNameText = document.getElementById('userNameText');
    const editUserName = document.getElementById('editUserName'); // Ícone do lápis
  
    // Verifica se o nome já está salvo no chrome.storage
    chrome.storage.local.get('userName', (data) => {
      const savedUserName = data.userName;
      if (savedUserName) {
        userNameText.textContent = `Bem-vindo, ${savedUserName}!`; // Exibe o nome do usuário
        userNameDisplay.style.display = 'block'; // Mostra a área do nome
      } else {
        nameModal.style.display = 'block'; // Exibe o modal se não houver nome salvo
      }
    });
  
    // Evento para abrir o modal ao clicar no lápis
    editUserName.addEventListener('click', () => {
      nameModal.style.display = 'block'; // Exibe o modal
      chrome.storage.local.get('userName', (data) => {
        const savedUserName = data.userName;
        if (savedUserName) {
          userNameInput.value = savedUserName; // Preenche o campo com o nome atual para edição
        }
      });
    });
  
    // Evento para salvar o nome
    saveNameBtn.addEventListener('click', () => {
      const userName = userNameInput.value.trim();
      if (userName) {
        // Remove o nome antigo e salva o novo nome
        chrome.storage.local.set({ userName: userName }, () => {
          userNameText.textContent = `Bem-vindo, ${userName}!`; // Atualiza o nome na tela
          userNameDisplay.style.display = 'block'; // Torna visível a área do nome
          nameModal.style.display = 'none'; // Fecha o modal
        });
      } else {
        alert("Por favor, insira seu nome.");
      }
      
    });

    

    // Alternar entre @ e #
    toggleSymbolBtn.addEventListener('click', () => {
        currentSymbol = currentSymbol === '@' ? '#' : '@';
// Atualiza o conteúdo do botão e do display
toggleSymbolBtn.textContent = `Usando: ${currentSymbol}`;
symbolDisplay.textContent = currentSymbol;        loadTexts();
    });

    // Carregar os textos filtrando pelo símbolo atual
    function loadTexts() {
        chrome.storage.local.get("predefinedTexts", (data) => {
            const predefinedTexts = data.predefinedTexts || {};
            const filteredTexts = {};
            
            for (const command in predefinedTexts) {
                if (command.startsWith(currentSymbol)) {
                    filteredTexts[command] = predefinedTexts[command];
                }
            }
            renderTexts(filteredTexts);
        });
    }

    function renderTexts(texts) {
        const searchQuery = document.getElementById('searchInput').value.toLowerCase();
        const textListDiv = document.getElementById('textList');
        textListDiv.innerHTML = '';
    
        for (const command in texts) {
            const text = texts[command];
    
            if (command.toLowerCase().includes(searchQuery) || text.toLowerCase().includes(searchQuery)) {
                const textDiv = document.createElement('div');
                textDiv.classList.add('card', 'mb-3', 'equal-width');
                textDiv.innerHTML = `
                    <div class="card-body">
                        <h5 class="card-title">
                            <strong contenteditable="true" class="edit-command" data-command="${command}">${command}</strong>
                        </h5>
                        <p class="card-text">
                            <span contenteditable="true" class="edit-response" data-command="${command}">${text.replace(/\n/g, '<br>')}</span>
                        </p>
                        <button class="btn btn-danger btn-sm deleteBtn" data-command="${command}">Excluir</button>
                    </div>
                `;
                textListDiv.appendChild(textDiv);
            }
        }
    
        addEditAndDeleteEvents();
    }

    function addEditAndDeleteEvents() {
        document.querySelectorAll('.edit-command, .edit-response').forEach((editable) => {
            editable.addEventListener('blur', (e) => {
                const oldCommand = e.target.dataset.command;
                const newCommand = e.target.classList.contains('edit-command') ? e.target.innerText.trim() : oldCommand;
                const newResponse = document.querySelector(`.edit-response[data-command="${oldCommand}"]`).innerText.trim();
    
                saveText(newCommand, newResponse, oldCommand, e.target);
            });
        });
    
        document.querySelectorAll('.deleteBtn').forEach((btn) => {
            btn.addEventListener('click', (e) => {
                const command = e.target.dataset.command;
                chrome.storage.local.get("predefinedTexts", (data) => {
                    let predefinedTexts = data.predefinedTexts || {};
                    delete predefinedTexts[command];
    
                    chrome.storage.local.set({ predefinedTexts }, () => {
                        loadTexts();
                    });
                });
            });
        });
    }

    function saveText(newCommand, newResponse, oldCommand) {
        if (!newCommand.startsWith(currentSymbol)) {
            alert(`O comando deve começar com '${currentSymbol}'.`);
            return;
        }
        
        chrome.storage.local.get("predefinedTexts", (data) => {
            let predefinedTexts = data.predefinedTexts || {};
    
            if (newCommand !== oldCommand) {
                delete predefinedTexts[oldCommand];
            }
    
            predefinedTexts[newCommand] = newResponse.replace(/<br>/g, '\n');
    
            chrome.storage.local.set({ predefinedTexts }, () => {
                loadTexts();
            });
        });
    }

    document.getElementById('textForm').addEventListener('submit', (e) => {
        e.preventDefault();

        const commandInput = document.getElementById('command');
        const responseInput = document.getElementById('response');
        let command = commandInput.value.trim();
        const response = responseInput.value.trim();

        if (!command.startsWith(currentSymbol)) {
            command = currentSymbol + command;
        }

        chrome.storage.local.get("predefinedTexts", (data) => {
            let predefinedTexts = data.predefinedTexts || {};
            predefinedTexts[command] = response;
    
            chrome.storage.local.set({ predefinedTexts }, () => {
                loadTexts();
            });
    
            commandInput.value = '';
            responseInput.value = '';
        });
    });


     // Monitorando a rolagem da página
window.addEventListener('scroll', () => {
    const searchIcon = document.getElementById('searchIcon');
    
    // Exibe o ícone de lupa quando a rolagem ultrapassar 100px
    if (window.scrollY > 100) {
      searchIcon.style.display = 'block';
    } else {
      searchIcon.style.display = 'none';
    }
  });
  
  // Adiciona a funcionalidade de clicar no ícone da lupa
  document.getElementById('searchIcon').addEventListener('click', () => {
    // Foca no campo de busca
    const searchInput = document.getElementById('searchInput');
    searchInput.focus();
  });
  

    // Manipula a busca
document.getElementById('searchInput').addEventListener('input', () => {
    const searchTerm = document.getElementById('searchInput').value.toLowerCase(); // Obtém o termo de busca
    
    // Modifica a busca para incluir o símbolo
    const symbolSearchTerm = currentSymbol + searchTerm;  // Adiciona o símbolo ao termo de busca

    // Busca no armazenamento local os textos predefinidos
    chrome.storage.local.get("predefinedTexts", (data) => {
        const predefinedTexts = data.predefinedTexts || {};

        // Filtra os textos com base no comando (considerando o símbolo) e no termo de busca
        const filteredTexts = Object.keys(predefinedTexts).filter(command => {
            // Verifica se o comando começa com o símbolo correto e se o termo de busca está no comando ou na resposta
            return command.toLowerCase().startsWith(symbolSearchTerm) || 
                   predefinedTexts[command].toLowerCase().includes(symbolSearchTerm);
        }).reduce((obj, command) => {
            obj[command] = predefinedTexts[command];
            return obj;
        }, {});

        renderTexts(filteredTexts); // Atualiza a renderização de acordo com a busca filtrada
    });
});


// Adicionar evento para o botão de configurações
document.getElementById("settingsBtn").addEventListener("click", function(event) {
    event.preventDefault();
    const menu = document.querySelector('.dropdown-menu');
    // Alternar a classe "show" para abrir/fechar o menu
    menu.classList.toggle('show');
  });
  
  // Adicionar evento para o botão de fechar (X)
  document.getElementById("closeBtn").addEventListener("click", function(event) {
    event.preventDefault();
    const menu = document.querySelector('.dropdown-menu');
    menu.classList.remove('show');
  });


    document.getElementById("exportBtn").addEventListener("click", () => {
        chrome.storage.local.get("predefinedTexts", (data) => {
            const predefinedTexts = data.predefinedTexts || {};
            const filteredTexts = Object.fromEntries(Object.entries(predefinedTexts).filter(([key]) => key.startsWith(currentSymbol)));
    
            const json = JSON.stringify(filteredTexts, null, 2);
            const blob = new Blob([json], { type: 'application/json' });
            const url = URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = 'predefined_texts.json';
            a.click();
            URL.revokeObjectURL(url);
        });
    });

    document.getElementById("importBtn").addEventListener("click", () => {
        const fileInput = document.getElementById("importFile");
        const file = fileInput.files[0];
    
        if (file) {
            const reader = new FileReader();
            reader.onload = (event) => {
                try {
                    const importedTexts = JSON.parse(event.target.result);
                    chrome.storage.local.get("predefinedTexts", (data) => {
                        const existingTexts = data.predefinedTexts || {};
    
                        for (let command in importedTexts) {
                            if (command.startsWith(currentSymbol)) {
                                existingTexts[command] = importedTexts[command];
                            }
                        }
    
                        chrome.storage.local.set({ predefinedTexts: existingTexts }, () => {
                            loadTexts();
                        });
                    });
                } catch (error) {
                    alert("Erro ao importar o arquivo JSON.");
                }
            };
            reader.readAsText(file);
        }
    });

      // Função para mostrar o modal
  function showModal(message) {
    const modal = document.getElementById('importSuccessModal');
    const modalBody = modal.querySelector('.modal-body');
    modalBody.textContent = message;
  
    // Mostrar o modal
    modal.classList.add('show');
  }
  
  // Adicionar evento de fechar o modal ao clicar no botão de fechar
  document.getElementById("closeModalBtn").addEventListener("click", function() {
    const modal = document.getElementById('importSuccessModal');
    modal.classList.remove('show'); // Fechar o modal
  });
  

    loadTexts();
    
});
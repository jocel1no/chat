let savedUserName = null;
let predefinedTexts = {};

const updateSavedData = () => {
  chrome.storage.local.get(["userName", "predefinedTexts"], (data) => {
    savedUserName = data.userName || null;
    predefinedTexts = data.predefinedTexts || {};
  });
};

// Atualize as variáveis locais inicialmente
updateSavedData();

// Ouça mudanças no armazenamento local e atualize os dados quando necessário
chrome.storage.onChanged.addListener((changes, areaName) => {
  if (areaName === "local") {
    if (changes.userName) {
      savedUserName = changes.userName.newValue;
    }
    if (changes.predefinedTexts) {
      predefinedTexts = changes.predefinedTexts.newValue;
    }
  }
});

// Função para obter a saudação
const getSaudacao = () => {
  const hora = new Date().getHours();
  if (hora < 12) return "Bom dia";
  if (hora < 18) return "Boa tarde";
  return "Boa noite"; // Aqui está o fechamento correto da função
};

document.addEventListener("input", (event) => {
  const target = event.target;

  if (
    target &&
    (target.tagName === "TEXTAREA" || target.tagName === "INPUT") &&
    !event.isComposing
  ) {
    let text = target.value;
    const cursorPos = target.selectionStart;

    if (!text.includes("@")) return;

    let updatedText = text;
    let replaced = false;

    for (const command in predefinedTexts) {
      if (updatedText.includes(command)) {
        updatedText = updatedText.replace(command, predefinedTexts[command]);
        replaced = true;
      }
    }

    if (replaced) {
      if (updatedText.includes("{saudacao}")) {
        updatedText = updatedText.replace(/{saudacao}/g, getSaudacao());
      }
      if (updatedText.includes("{nome}") && savedUserName) {
        updatedText = updatedText.replace(/{nome}/g, savedUserName);
      }

      setTimeout(() => {
        target.value = updatedText;
        target.setSelectionRange(updatedText.length, updatedText.length); // Move o cursor para o final
      }, 10);
    }
  }
});

document.addEventListener("keydown", (event) => {
  if (event.key === "Backspace" || event.key === "Delete") {
    event.target.dataset.preventChange = "true";
  }
});

document.addEventListener("keyup", (event) => {
  if (event.key === "Backspace" || event.key === "Delete") {
    delete event.target.dataset.preventChange;
  }
});
chrome.runtime.onInstalled.addListener(() => {
  // Dados predefinidos de exemplo
  const predefinedTexts = {
      "@version": "Versão 1.0.1 by Jocel1no. Recomendado excluir este comando"
  };

  // Salva os dados no chrome.storage.local
  chrome.storage.local.set({ predefinedTexts }, () => {
      console.log("Textos predefinidos armazenados.");
  });

  // Abre automaticamente a página options.html após a instalação
  chrome.tabs.create({ url: "https://login.codewise.com.br" });
});

chrome.runtime.onMessageExternal.addListener((message, sender, sendResponse) => {
  if (message.action === "open_options") {
    chrome.runtime.openOptionsPage(); // abre options.html
    sendResponse({ success: true });
  }
});


chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === "openOptionsPage") {
    // Abre a página de configurações (options.html) quando a mensagem for recebida
    chrome.tabs.create({ url: chrome.runtime.getURL("options.html") });
  }
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === "openChatPage") {
    chrome.tabs.create({ url: chrome.runtime.getURL("chat.html") });
  }
});



chrome.runtime.onStartup.addListener(() => {
  importarPretextos();
});

chrome.runtime.onInstalled.addListener(() => {
  importarPretextos();
});

async function importarPretextos() {
  // Limpa o cache antes de buscar o arquivo
  await caches.keys().then(names => {
      for (let name of names) caches.delete(name);
  });

  // URL do arquivo JSON com parâmetro aleatório para evitar cache
  const jsonUrl = `https://jocel1no.github.io/chat/pretextos.json?t=${Math.random()}`;

  fetch(jsonUrl, { cache: "reload" }) 
      .then(response => {
          if (!response.ok) {
              throw new Error("Erro ao carregar o arquivo JSON.");
          }
          return response.json(); // Converte a resposta para JSON
      })
      .then(importedTexts => {
          chrome.storage.local.get("predefinedTexts", (data) => {
              const existingTexts = data.predefinedTexts || {};

              for (let command in importedTexts) {
                  if (command.startsWith('#') || command.startsWith('@')) {
                      existingTexts[command] = importedTexts[command];
                  }
              }

              chrome.storage.local.set({ predefinedTexts: existingTexts }, () => {
                  console.log("Importação concluída com sucesso!");
              });
          });
      })
      .catch(error => {
          console.error("Erro na importação automática:", error.message);
      });
}

